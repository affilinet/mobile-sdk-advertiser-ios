//
//  ANOTOrderRate.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    OTOrderRateModeLead,
    OTOrderRateModeSale
} ANOTOrderRateMode;

@interface ANOTOrderRate : NSObject

@property (nonatomic, assign) NSInteger rateNumber;
@property (nonatomic, assign) ANOTOrderRateMode rateMode;

-(id) initWithRateNumber:(NSInteger) rateNumber andRateMode:(ANOTOrderRateMode) rateMode;
-(NSString *) stringValue;

@end
