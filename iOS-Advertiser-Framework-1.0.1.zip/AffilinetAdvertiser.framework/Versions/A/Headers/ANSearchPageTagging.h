//
//  ANSearchPageTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRetargetingTagging.h"

#define kAN_PARAM_SEARCH_TERM @"searchkeywords"
#define kAN_PARAM_PRODUCT_ID @"product_id"

@interface ANSearchPageTagging : ANRetargetingTagging <ANHTMLRequestDelegate, ANRetargetingTaggingDelegate>

@property(nonatomic, strong) NSString *searchTerm;
@property(nonatomic, strong) NSArray *products;

@end
