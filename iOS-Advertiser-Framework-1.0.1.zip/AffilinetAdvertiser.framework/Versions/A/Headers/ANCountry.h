//
//  ANCountry.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    CountryCodeGermany,
    CountryCodeAustria,
    CountryCodeSwitzerland,
    CountryCodeUnitedKingdom,
    CountryCodeFrance,
    CountryCodeSpain,
    CountryCodeNetherlands
} ANCountryCode;

@interface ANCountry : NSObject

-(id) initWithCountryCode:(ANCountryCode) countryCode;
-(NSString *) stringValue;
-(NSString *) domain;
-(NSString *) programID;
-(NSString *) containerTrackingDomain;
-(NSString *) trackingDomain;

@end
