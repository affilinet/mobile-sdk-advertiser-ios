//
//  ANTransactionOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANOrderTracking.h"
#import "ANOTOrderRate.h"

@interface ANTransactionOrderTracking : ANOrderTracking <ANHTMLRequestDelegate>

@property (nonatomic, assign) double orderValue;
@property (nonatomic, strong) ANOTOrderRate *orderRate;

@end
