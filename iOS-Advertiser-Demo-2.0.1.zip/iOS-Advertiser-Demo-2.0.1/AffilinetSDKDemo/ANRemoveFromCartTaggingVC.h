//
//  ANRemoveFromCartTaggingVC.h
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANRequestVC.h"

@interface ANRemoveFromCartTaggingVC : ANRequestVC

@end
