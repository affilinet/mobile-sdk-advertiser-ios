//
//  ANBasketTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANBasketTrackingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANBasketTrackingVC ()

@property (nonatomic, strong) ANBasketTracking *basketTracking;

@end

@implementation ANBasketTrackingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        self.basketTracking = [[ANBasketTracking alloc] initWithSession:[ANSession sharedInstance]];
        
        self.basketTracking.mediaType = [[ANOTOrderMediaType alloc] init];
        self.basketTracking.mediaType.mediaType = OTMediaTypeGraphicBanner;
        self.basketTracking.mediaType.mediaNumber = 1;
        
        self.basketTracking.voucherCode = @"TEST";
        self.basketTracking.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.basketTracking.orderDate = [NSDate date];
        //self.basketTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3"]];
        self.basketTracking.orderId = [NSString stringWithFormat:@"iOS-Basket-%@", (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        
        ANOTBasketItem *item1 = [[ANOTBasketItem alloc] init];
        item1.quantity = 2;
        item1.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item1.productName = @"Amazing Product 1";
        item1.singlePrice = 40.45;
        item1.properties = @[@"size_large",@"colour_green",@"style_bootCut"];
        item1.brand = @"brand1";
        item1.category = @"category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1/category1 category1";
        
        ANOTBasketItem *item2 = [[ANOTBasketItem alloc] init];
        item2.quantity = 4;
        item2.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item2.productName = @"Amazing Product 2";
        item2.singlePrice = 40.45;
        
        self.basketTracking.basketItems = @[item1, item2];

        self.requests = @[self.basketTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
