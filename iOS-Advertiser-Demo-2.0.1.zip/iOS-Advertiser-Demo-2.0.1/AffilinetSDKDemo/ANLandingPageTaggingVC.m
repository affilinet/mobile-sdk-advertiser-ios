//
//  ANLandingPageTaggingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANLandingPageTaggingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANLandingPageTaggingVC ()

//@property (nonatomic, strong) ANLandingpageTagging *landingTagging; //deprecated
@property (nonatomic, strong) ANPageViewTagging *pageViewTagging;

@end

@implementation ANLandingPageTaggingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        //self.landingTagging = [[ANLandingpageTagging alloc] initWithSession:[ANSession sharedInstance]]; //deprecated
        self.pageViewTagging = [[ANPageViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        
        self.pageViewTagging.pageName = @"Page View Tagging";
        self.pageViewTagging.pageCategory = @"Page View Tagging";
        self.pageViewTagging.pageType = @"Page View Tagging";
        self.pageViewTagging.pageURL = @"http://affilinet.com/SDKDemo/pageViewTagging";
        
        self.requests = @[self.pageViewTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
