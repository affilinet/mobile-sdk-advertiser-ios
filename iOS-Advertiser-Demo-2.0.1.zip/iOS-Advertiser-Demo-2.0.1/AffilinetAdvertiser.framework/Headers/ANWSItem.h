//
//  ANWSItem.h
//  AffilinetSDK
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ANWSItem <NSObject>

@end
