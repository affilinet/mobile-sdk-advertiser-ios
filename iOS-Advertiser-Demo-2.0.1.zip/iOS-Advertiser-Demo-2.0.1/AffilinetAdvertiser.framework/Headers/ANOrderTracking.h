//
//  ANOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"
#import "ANOTOrderAdType.h"
#import "ANCurrency.h"

#define kAN_PARAM_SITE @"site"
#define kAN_PARAM_ORDER @"order"
#define kAN_PARAM_AFFMT @"affmt"
#define kAN_PARAM_AFFMN @"affmn"
#define kAN_PARAM_VCODE @"vCode"
#define kAN_PARAM_CURR @"curr"
#define kAN_PARAM_PSUB @"pSub"
#define kAN_PARAM_SDK_VERSION @"pSub4"
#define kAN_PARAM_PROGRAM_SUB @"program_subid"

__deprecated_msg("ANOrderTracking is deprecated please use ANACTOrderTracking instead.")
@interface ANOrderTracking : ANHTMLRequest

@property (nonatomic, strong) NSString *orderID;
@property (nonatomic, strong) ANOTOrderAdType *adType;
@property (nonatomic, strong) NSString *vCode;
@property (nonatomic, strong) NSArray *pSub;
@property (nonatomic, strong) ANCurrency *currency;

-(NSString *) paramsString;

@end
