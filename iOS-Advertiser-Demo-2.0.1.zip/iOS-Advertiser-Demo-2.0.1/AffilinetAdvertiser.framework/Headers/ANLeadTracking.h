//
//  ANLeadTracking.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 28/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANACTOrderTracking.h"
#import "ANOTOrderRate.h"

@interface ANLeadTracking : ANACTOrderTracking

@property (nonatomic, strong) ANRTOrder *order;

@end
