//
//  Currency.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kCurrencyCodeEUR @"EUR"
#define kCurrencyCodeUSD @"USD"
#define kCurrencyCodeBGN @"BGN"
#define kCurrencyCodeDKK @"DKK"
#define kCurrencyCodeGBP @"GBP"
#define kCurrencyCodeLTL @"LTL"
#define kCurrencyCodeCAD @"CAD"
#define kCurrencyCodeCHF @"CHF"

@interface ANCurrency : NSObject

-(id) initWithStringCode:(NSString *) code;
-(NSString *) stringValue;

@end
