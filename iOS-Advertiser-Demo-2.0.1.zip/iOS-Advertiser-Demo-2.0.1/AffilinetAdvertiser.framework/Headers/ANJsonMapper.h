//
//  ANJsonMapper.h
//  AffilinetSDK
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSShop.h"

@protocol ANJsonMapperDelegate <NSObject>

-(void) mapDictionaryToObject;
-(NSArray *) items;

@optional
-(NSArray *) facets;

@end

@interface ANJsonMapper : NSObject

@property (nonatomic, strong, readonly) NSDictionary *dictionary;
@property (nonatomic, assign) NSInteger currentPage;
@property (nonatomic, assign) NSInteger totalPages;
@property (nonatomic, assign) NSInteger records;
@property (nonatomic, assign) NSInteger totalRecords;
@property (nonatomic, strong) ANWSShop *shop;

-(id) initWithDictionary:(NSDictionary *) dictionary;

-(void) mapSummaryWithDictionary:(NSDictionary *) summary;

@end
