//
//  ANHTTPConnection.h
//  AffilinetSDK
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//  Thanks to jcesar solution @ stackoverflow.com/questions/14914480/nsurlconnection-with-blocks
//

#import <Foundation/Foundation.h>

@interface ANHTTPConnection : NSObject <NSURLConnectionDelegate, NSURLConnectionDataDelegate> {
    NSURLConnection * internalConnection;
    NSMutableData * container;
}

-(id)initWithRequest:(NSURLRequest *)req;

@property (nonatomic,copy)NSURLConnection * internalConnection;
@property (nonatomic,copy)NSURLRequest *request;
@property (nonatomic,copy)void (^completitionBlock) (id obj, NSError * err);


-(void)start;

@end
