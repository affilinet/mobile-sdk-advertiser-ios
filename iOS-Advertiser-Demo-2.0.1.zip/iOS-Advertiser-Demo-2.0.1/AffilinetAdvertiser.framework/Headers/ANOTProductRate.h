//
//  ANOTProductRate.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 31/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    OTProductRateModeLead,
    OTProductRateModeSale
} ANOTProductRateMode;

@interface ANOTProductRate : NSObject

@property (nonatomic, assign) NSInteger rateNumber;
@property (nonatomic, assign) ANOTProductRateMode rateMode;

-(id) initWithRateNumber:(NSInteger) rateNumber andRateMode:(ANOTProductRateMode) rateMode;
-(NSString *) stringValue;

@end
