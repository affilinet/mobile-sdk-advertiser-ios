//
//  ANAdvertiserAccount.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAccount.h"

@interface ANAdvertiserAccount : ANAccount
+(instancetype)advertiserAccountWithIDs:(NSArray <NSNumber*>*)accountIDs;
@property(nonatomic, strong) NSString *webServiceUsername;

@end
