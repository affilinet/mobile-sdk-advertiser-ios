//
//  NSDate+ISO8601.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (ISO8601)

-(NSString *) dateToISO8601String;
-(NSString *) dateToString;

@end
