//
//  ANCustomerDataTaggingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANCustomerDataTaggingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANCustomerDataTaggingVC ()

@property (nonatomic, strong) ANCustomerDataTagging *customerTag;

@end

@implementation ANCustomerDataTaggingVC

- (id) initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        self.customerTag = [[ANCustomerDataTagging alloc] initWithSession:[ANSession sharedInstance]];
        
        self.requests = @[self.customerTag];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
