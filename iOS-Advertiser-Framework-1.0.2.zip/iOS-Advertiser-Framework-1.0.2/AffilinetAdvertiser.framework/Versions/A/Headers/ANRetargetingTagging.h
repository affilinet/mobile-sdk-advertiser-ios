//
//  ANRetargetingTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"

#define kAN_PARAM_TYPE @"type"
#define kAN_PARAM_SITE @"site"

@protocol ANRetargetingTaggingDelegate <NSObject>

-(NSString *) getJavascriptParamsBody;

@end

@interface ANRetargetingTagging : ANHTMLRequest


@end
