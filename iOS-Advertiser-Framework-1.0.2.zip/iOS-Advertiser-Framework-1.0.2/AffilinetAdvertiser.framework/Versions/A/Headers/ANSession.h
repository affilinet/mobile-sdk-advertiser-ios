//
//  ANSession.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANAccount.h"
#import "ANCountry.h"
#import "ANRequest.h"
#import "ANRequestResponse.h"

@class ANRequest;

@interface ANSession : NSObject

@property (nonatomic, strong, readonly) ANAccount *account;
@property (nonatomic, strong, readonly) ANCountry *country;

@property (copy) void(^onRequestResponse)(ANRequest *, ANRequestResponse *);
@property (copy) void(^onRequestsError)(NSError *);
@property (copy) void(^onRequestsFinished)(void);


+(id) sharedInstance;

-(void) openWithAccount:(ANAccount *) account andCountryCode:(ANCountryCode) countryCode;
-(void) executeRequests:(NSArray *) requests;

@end
