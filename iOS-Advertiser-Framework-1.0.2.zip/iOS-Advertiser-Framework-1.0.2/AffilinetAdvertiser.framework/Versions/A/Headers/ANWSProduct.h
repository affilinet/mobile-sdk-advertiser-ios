//
//  ANWSProduct.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSShop.h"
#import "ANWSPriceInformation.h"
#import "ANWSProductProperty.h"
#import "ANWSItem.h"
#import "ANWSCategory.h"
#import "ANWSProductImageCollection.h"

@interface ANWSProduct : NSObject <ANWSItem>

@property (nonatomic, assign) NSInteger productId;
@property (nonatomic, strong) NSString *articleNumber;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *description;
@property (nonatomic, strong) NSString *descriptionShort;
@property (nonatomic, assign) double score;
@property (nonatomic, strong) NSDate *lastProductChange;
@property (nonatomic, strong) NSDate *lastShopUpdate;
@property (nonatomic, strong) NSString *availability;
@property (nonatomic, strong) NSString *deliveryTime;
@property (nonatomic, strong) NSString *deeplink1;
@property (nonatomic, strong) NSString *deeplink2;
@property (nonatomic, strong) NSString *brand;
@property (nonatomic, strong) NSString *manufactor;
@property (nonatomic, strong) NSString *distributor;
@property (nonatomic, strong) NSString *EAN;
@property (nonatomic, strong) NSString *keywords;
@property (nonatomic, strong) ANWSShop *shop;
@property (nonatomic, strong) NSArray *properties;
@property (nonatomic, strong) ANWSPriceInformation *priceInformation;
@property (nonatomic, strong) NSArray *imageCollections;
@property (nonatomic, strong) NSArray *affilinetCategories;
@property (nonatomic, strong) NSArray *shopCategories;


@end
