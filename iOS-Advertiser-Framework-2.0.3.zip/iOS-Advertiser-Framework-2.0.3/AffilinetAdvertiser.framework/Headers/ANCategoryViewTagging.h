//
//  ANCategoryViewTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANACTTagging.h"
#import "ANRTProductCategory.h"

@interface ANCategoryViewTagging : ANACTTagging

@property (nonatomic, strong) ANRTProductCategory *category;
@property(nonatomic, strong) NSString *refererURL;

@end
