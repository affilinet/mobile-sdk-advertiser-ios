//
//  ANHTMLRequest.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRequest.h"

#define kAN_ENDPOINT_REGISTER_SALE @"/registersale.asp"
#define kAN_ENDPOINT_PARAM @"/art/JS/param.aspx"

@protocol ANHTMLRequestDelegate <NSObject>

-(BOOL) isValid:(ANSession *) session withError:(NSError **)error;
-(NSString *) buildHtmlDocument:(ANSession *) session;

@end

@interface ANHTMLRequest : ANRequest

-(NSString *) html:(NSError **)error;

@end
