//
//  ANBasketTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANBasketTrackingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANBasketTrackingVC ()

@property (nonatomic, strong) ANBasketOrderTracking *basketTracking;

@end

@implementation ANBasketTrackingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        self.basketTracking = [[ANBasketOrderTracking alloc] initWithSession:[ANSession sharedInstance]];
        self.basketTracking.orderID = [NSString stringWithFormat:@"iOS-Basket-%@", (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        self.basketTracking.mediaType = [[ANOTOrderMediaType alloc] init];
        self.basketTracking.mediaType.mediaType = OTMediaTypeGraphicBanner;
        self.basketTracking.mediaType.mediaNumber = 1;
        self.basketTracking.vCode = @"TEST";
        self.basketTracking.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
        self.basketTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3"]];
        
        ANOTBasketItem *basketItem = [[ANOTBasketItem alloc] init];
        basketItem.articleNumber = @"ArticleNb1";
        basketItem.productName = @"Amazing Product";
        basketItem.category = @"jeans";
        basketItem.brand = @"Versace";
        basketItem.quantity = 1;
        basketItem.singlePrice = 200.45;
        basketItem.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3"]];
        
        ANOTBasketItem *basketItem2 = [[ANOTBasketItem alloc] init];
        basketItem2.articleNumber = @"ArticleNb2";
        basketItem2.productName = @"Amazing Product 2";
        basketItem2.category = @"jeans 2";
        basketItem2.brand = @"Versace 2";
        basketItem2.quantity = 3;
        basketItem2.singlePrice = 600.45;
        basketItem2.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3"]];
        
        self.basketTracking.items = [NSMutableArray arrayWithArray:@[basketItem, basketItem2]];

        self.requests = @[self.basketTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
