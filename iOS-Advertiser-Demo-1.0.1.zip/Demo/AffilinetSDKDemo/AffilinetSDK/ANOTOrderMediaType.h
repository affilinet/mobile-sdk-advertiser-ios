//
//  OTOrderMediaType.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    OTMediaTypeGraphicBanner,
    OTMediaTypeHTMLBanner,
    OTMediaTypeTextBanner
} ANOTMediaType;

@interface ANOTOrderMediaType : NSObject

@property (nonatomic, assign) NSInteger mediaNumber;
@property (nonatomic, assign) ANOTMediaType mediaType;

-(NSString *) getStringValue;

@end
