//
//  ANProductViewTaggingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANProductViewTaggingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANProductViewTaggingVC ()

@property(nonatomic, strong) ANProductViewTagging *productTagging;
@property(nonatomic, strong) ANProductViewTagging *datingTagging;
@property(nonatomic, strong) ANProductViewTagging *travelTagging;

@end

@implementation ANProductViewTaggingVC

-(id) initWithStyle:(UITableViewStyle)style {
    self = [super initWithStyle:style];
    if(self) {
        // default product
        ANRTProduct *product = [[ANRTProduct alloc] init];
        product.category = [[ANRTProductCategory alloc] init];
        product.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing Product";
        product.price = 5.43;
        product.oldPrice = 5.99;
        product.brand = @"Amazing Brand";
        product.rating = 3;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http://something-product.com";
        product.imageURL = @"http://something-product.com/image.png";
        
        self.productTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.productTagging.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
        self.productTagging.product = product;
        
        // dating product
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        datingProduct.category = [[ANRTProductCategory alloc] init];
        datingProduct.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        datingProduct.productId = [NSString stringWithFormat:@"dating-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        datingProduct.name = @"Amazing Dating Product";
        datingProduct.price = 22.43;
        datingProduct.oldPrice = 19.99;
        datingProduct.brand = @"Amazing Dating Brand";
        datingProduct.rating = 3;
        datingProduct.inStock = YES;
        datingProduct.onSale = YES;
        datingProduct.accessory = NO;
        datingProduct.clickURL = @"http://something-dating.com";
        datingProduct.imageURL = @"http://something-dating.com/image.png";
        
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        customer.gender = @"male";
        customer.ageRange = @"18-25";
        customer.zipCode = @"60329";
        customer.wasLoggedIn = NO;
        datingProduct.customer = customer;
        
        self.datingTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.datingTagging.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
        self.datingTagging.product = datingProduct;
    
        // travel product
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        travelProduct.category = [[ANRTProductCategory alloc] init];
        travelProduct.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        travelProduct.productId = [NSString stringWithFormat:@"travel-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        travelProduct.name = @"Amazing Travel Product";
        travelProduct.price = 199.95;
        travelProduct.oldPrice = 189.60;
        travelProduct.brand = @"Amazing Travel Brand";
        travelProduct.rating = 7;
        travelProduct.inStock = YES;
        travelProduct.onSale = NO;
        travelProduct.accessory = YES;
        travelProduct.clickURL = @"http://something-travel.com";
        travelProduct.imageURL = @"http://something-travel.com/image.png";
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSince1970:1385025186];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSince1970:1390294999];
        travelProduct.productType = @"Hotel";
        travelProduct.kids = YES;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"Deluxe";
        travelProduct.pointOfDeparture = @"Frankfurt am Main";
        travelProduct.pointOfDestination = @"Dubai";
        
        self.travelTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.travelTagging.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
        self.travelTagging.product = travelProduct;
        
        self.requests = @[self.productTagging, self.datingTagging, self.travelTagging];
    }
    
    return self;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 12;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    switch (indexPath.row) {
        case 0: {
            cell.textLabel.text = @"Product ID";
            cell.detailTextLabel.text = self.productTagging.product.productId;
        }
            break;
        case 1: {
            cell.textLabel.text = @"Product Name";
            cell.detailTextLabel.text = self.productTagging.product.name;
        }
            break;
        case 2: {
            cell.textLabel.text = @"Price";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.productTagging.product.price];
        }
            break;
        case 3: {
            cell.textLabel.text = @"Old Price";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.productTagging.product.oldPrice];
        }
            break;
        case 4: {
            cell.textLabel.text = @"Currency";
            cell.detailTextLabel.text = [self.productTagging.currency stringValue];
        }
            break;
        case 5: {
            cell.textLabel.text = @"Brand";
            cell.detailTextLabel.text = self.productTagging.product.brand;
        }
            break;
        case 6: {
            cell.textLabel.text = @"Rating";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.productTagging.product.rating];
        }
            break;
        case 7: {
            cell.textLabel.text = @"In Stock";
            cell.detailTextLabel.text = self.productTagging.product.inStock ? @"Yes" : @"No";
        }
            break;
        case 8: {
            cell.textLabel.text = @"On Sale";
            cell.detailTextLabel.text = self.productTagging.product.onSale ? @"Yes" : @"No";
        }
            break;
        case 9: {
            cell.textLabel.text = @"Accessory";
            cell.detailTextLabel.text = self.productTagging.product.accessory ? @"Yes" : @"No";
        }
            break;
        case 10: {
            cell.textLabel.text = @"Click Url";
            cell.detailTextLabel.text = self.productTagging.product.clickURL;
        }
            break;
        case 11: {
            cell.textLabel.text = @"Image Url";
            cell.detailTextLabel.text = self.productTagging.product.imageURL;
        }
            break;
        default:
            break;
    }
    
    return cell;
}

@end
