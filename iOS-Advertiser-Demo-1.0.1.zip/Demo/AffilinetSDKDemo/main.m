//
//  main.m
//  AffilinetSDKDemo
//
//  Created by Joao Santos on 28/10/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ANAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ANAppDelegate class]));
    }
}
