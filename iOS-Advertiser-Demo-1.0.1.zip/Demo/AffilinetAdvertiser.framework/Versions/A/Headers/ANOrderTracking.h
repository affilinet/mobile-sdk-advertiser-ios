//
//  ANOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"
#import "ANOTOrderMediaType.h"
#import "ANCurrency.h"

#define kAN_PARAM_SITE @"site"
#define kAN_PARAM_ORDER @"order"
#define kAN_PARAM_AFFMT @"affmt"
#define kAN_PARAM_AFFMN @"affmn"
#define kAN_PARAM_VCODE @"vCode"
#define kAN_PARAM_CURR @"curr"
#define kAN_PARAM_PSUB @"pSub"
#define kAN_PARAM_SDK_VERSION @"pSub4"

@interface ANOrderTracking : ANHTMLRequest

@property (nonatomic, strong) NSString *orderID;
@property (nonatomic, strong) ANOTOrderMediaType *mediaType;
@property (nonatomic, strong) NSString *vCode;
@property (nonatomic, strong) NSArray *pSub;
@property (nonatomic, strong) ANCurrency *currency;

-(NSString *) paramsString;

@end
