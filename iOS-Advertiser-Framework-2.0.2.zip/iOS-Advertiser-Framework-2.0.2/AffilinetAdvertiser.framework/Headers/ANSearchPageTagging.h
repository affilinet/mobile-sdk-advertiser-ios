//
//  ANSearchPageTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANACTTagging.h"
@class ANRTProduct;

@interface ANSearchPageTagging : ANACTTagging

@property(nonatomic, strong) NSString *searchTerm DEPRECATED_MSG_ATTRIBUTE("searchTerm is deprecated, please use keywords instead.");
@property(nonatomic, strong) NSArray <NSString *> *keywords;
@property(nonatomic, strong) NSArray <ANRTProduct *> *products;

@property(nonatomic, strong) NSString *refererURL;

@end
