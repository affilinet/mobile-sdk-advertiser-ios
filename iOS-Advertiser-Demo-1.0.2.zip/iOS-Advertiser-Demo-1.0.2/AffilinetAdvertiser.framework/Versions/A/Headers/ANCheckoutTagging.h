//
//  ANCheckoutTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrder.h"

#define kAN_PARAM_ORDER_ID @"order_id"
#define kAN_PARAM_ORDER_TOTAL @"order_total"
#define kAN_PARAM_ORDER_PRODUCT_IDS @"order_productids"
#define kAN_PARAM_ORDER_QUANTITY @"order_quantity"
#define kAN_PARAM_ORDER_PRICES @"order_prices"

@interface ANCheckoutTagging : ANAmountTagging <ANHTMLRequestDelegate, ANRetargetingTaggingDelegate>

@property (nonatomic, strong) ANRTOrder *order;

@end
