//
//  ANSearchTermTaggingVC.h
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANRequestVC.h"

@interface ANSearchTermTaggingVC : ANRequestVC

@end
