//
//  ANRTProduct.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANRTProductCategory.h"

@interface ANRTProduct : NSObject

@property (nonatomic, strong) NSString *productId;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) double price;
@property (nonatomic, assign) double oldPrice;
@property (nonatomic, strong) NSString *brand;
@property (nonatomic, assign) NSInteger rating;
@property (nonatomic, assign) BOOL inStock;
@property (nonatomic, assign) BOOL onSale;
@property (nonatomic, assign) BOOL accessory;
@property (nonatomic, strong) NSString *clickURL;
@property (nonatomic, strong) NSString *imageURL;
@property (nonatomic, strong) ANRTProductCategory *category;


@end
