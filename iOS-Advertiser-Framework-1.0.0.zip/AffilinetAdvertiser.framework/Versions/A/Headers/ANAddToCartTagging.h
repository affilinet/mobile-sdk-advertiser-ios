//
//  ANAddToCartTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"

@interface ANAddToCartTagging : ANAmountTagging <ANHTMLRequestDelegate, ANRetargetingTaggingDelegate>

@property (nonatomic, strong) NSArray *items;

@end
