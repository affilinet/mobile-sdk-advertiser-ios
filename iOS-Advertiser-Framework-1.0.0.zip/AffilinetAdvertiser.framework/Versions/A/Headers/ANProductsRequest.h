//
//  ANProductsRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANWebserviceRequest.h"
#import "ANWSShopLogoScale.h"
#import "ANWSProductImageScale.h"


@interface ANProductsRequest : ANWebserviceRequest

@property (nonatomic, assign, readonly) NSArray *logoScales;
@property (nonatomic, assign, readonly) NSArray *imageScales;

-(void) addShopLogoScale:(ANWSShopLogoScale) scale;
-(void) addProductImageScale:(ANWSProductImageScale) scale;

-(NSString *) imageScalesJoinedByString:(NSArray *) imageScales;
-(NSString *) logoScalesJoinedByString:(NSArray *) logoScales;

@end
