//
//  ANLandingPageTaggingVC.m
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 08/11/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANLandingPageTaggingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANLandingPageTaggingVC ()

@property (nonatomic, strong) ANLandingpageTagging *landingTagging;

@end

@implementation ANLandingPageTaggingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.landingTagging = [[ANLandingpageTagging alloc] initWithSession:[ANSession sharedInstance]];
        
        self.requests = @[self.landingTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
