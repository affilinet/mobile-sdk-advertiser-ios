//
//  ANTransactionOrderTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 07/11/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANTransactionOrderTrackingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANTransactionOrderTrackingVC ()

@property (nonatomic, strong) ANTransactionOrderTracking *orderTracking;

@end

@implementation ANTransactionOrderTrackingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.orderTracking = [[ANTransactionOrderTracking alloc] initWithSession:[ANSession sharedInstance]];
        self.orderTracking.orderID =  (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.orderTracking.mediaType = [[ANOTOrderMediaType alloc] init];
        self.orderTracking.mediaType.mediaType = OTMediaTypeGraphicBanner;
        self.orderTracking.mediaType.mediaNumber = 1;
        self.orderTracking.vCode = @"test-vCode";
        self.orderTracking.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
        self.orderTracking.orderValue = 220.45;
        self.orderTracking.orderRate = [[ANOTOrderRate alloc] init];
        self.orderTracking.orderRate.rateNumber = 1;
        self.orderTracking.orderRate.rateMode = OTOrderRateModeSale;
        self.orderTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3", @"example4"]];
        
        self.requests = @[self.orderTracking];
    }
    return self;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 11;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    switch (indexPath.row) {
        case 0: {
            cell.textLabel.text = @"Order ID";
            cell.detailTextLabel.text = self.orderTracking.orderID;
        }
            break;
        case 1: {
            cell.textLabel.text = @"Media Type";
            cell.detailTextLabel.text = [self.orderTracking.mediaType stringValue];
        }
            break;
        case 2: {
            cell.textLabel.text = @"Media Number";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.orderTracking.mediaType.mediaNumber];
        }
            break;
        case 3: {
            cell.textLabel.text = @"Voucher Code";
            cell.detailTextLabel.text = self.orderTracking.vCode;
        }
            break;
        case 4: {
            cell.textLabel.text = @"Currency";
            cell.detailTextLabel.text = [self.orderTracking.currency stringValue];
        }
            break;
        case 5: {
            cell.textLabel.text = @"Order Value";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.orderTracking.orderValue];
        }
            break;
        case 6: {
            cell.textLabel.text = @"Rate Mode";
            cell.detailTextLabel.text = [self.orderTracking.orderRate stringValue];
        }
            break;
        case 7: {
            cell.textLabel.text = @"Rate Number";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.orderTracking.orderRate.rateNumber];
        }
            break;
        case 8: {
            cell.textLabel.text = @"Sub";
            cell.detailTextLabel.text = @"";
            for(NSString * sub in self.orderTracking.pSub) {
                cell.detailTextLabel.text = [cell.detailTextLabel.text stringByAppendingFormat:@" %@", sub];
            }
        }
            break;
        default:
            break;
    }
    
    return cell;
}

@end
