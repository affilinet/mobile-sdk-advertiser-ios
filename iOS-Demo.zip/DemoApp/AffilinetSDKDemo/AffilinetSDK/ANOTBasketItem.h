//
//  ANOTBasketItem.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANOTOrderRate.h"

@interface ANOTBasketItem : NSObject

@property (nonatomic, strong) NSString *articleNumber;
@property (nonatomic, strong) NSString *productName;
@property (nonatomic, strong) NSString *category;
@property (nonatomic, assign) NSInteger quantity;
@property (nonatomic, assign) double singlePrice;
@property (nonatomic, strong) NSString *brand;
@property (nonatomic, strong) NSMutableArray *properties;
@property (nonatomic, strong) ANOTOrderRate *orderRate;

-(NSString *) getAsParamString;

@end
