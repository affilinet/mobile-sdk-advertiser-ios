//
//  main.m
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 28/10/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ANAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ANAppDelegate class]));
    }
}
