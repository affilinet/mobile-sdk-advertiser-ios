//
//  ANTransactionOrderTrackingVC.h
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 07/11/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ANRequestVC.h"

@interface ANTransactionOrderTrackingVC : ANRequestVC

@end
