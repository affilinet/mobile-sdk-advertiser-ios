//
//  ANAppDelegate.h
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 28/10/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
