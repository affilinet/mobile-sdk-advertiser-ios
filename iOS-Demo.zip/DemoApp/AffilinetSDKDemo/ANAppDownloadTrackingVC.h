//
//  ANAppDownloadTrackingVC.h
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 08/11/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANRequestVC.h"

@interface ANAppDownloadTrackingVC : ANRequestVC

@end
