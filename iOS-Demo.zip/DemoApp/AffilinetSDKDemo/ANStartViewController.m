//
//  ANStartViewController.m
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 29/10/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANStartViewController.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

#import "ANTransactionOrderTrackingVC.h"
#import "ANProductViewTaggingVC.h"
#import "ANAddToCartTaggingVC.h"
#import "ANCheckoutTaggingVC.h"
#import "ANBasketTrackingVC.h"
#import "ANAppDownloadTrackingVC.h"
#import "ANCategoryViewTaggingVC.h"
#import "ANLandingPageTaggingVC.h"
#import "ANCustomerDataTaggingVC.h"
#import "ANSearchTermTaggingVC.h"

@interface ANStartViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation ANStartViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor grayColor];
        
        self.tableView = [[UITableView alloc] initWithFrame:(CGRect){{0,0}, self.view.frame.size} style:UITableViewStylePlain];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        [self.view addSubview:self.tableView];
        
        ANAdvertiserAccount *account = [[ANAdvertiserAccount alloc] init];
        account.accountID = 12452;
        [[ANSession sharedInstance] openWithAccount:account andCountryCode:CountryCodeGermany];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark UITableViewDelegate methods

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0) {
        switch (indexPath.row) {
            case 0: {
                ANTransactionOrderTrackingVC *orderTrackingVC = [[ANTransactionOrderTrackingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:orderTrackingVC animated:YES];
                
            }
                break;
            case 1: {
                ANBasketTrackingVC *basketTrackingVC = [[ANBasketTrackingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:basketTrackingVC animated:YES];
            }
                break;
            case 2: {
                ANAppDownloadTrackingVC *appDownloadVC = [[ANAppDownloadTrackingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:appDownloadVC animated:YES];
            }
                break;
            default:
                break;
        }
    }
    else if(indexPath.section == 1) {
        switch (indexPath.row) {
            case 0: {
                ANProductViewTaggingVC *productTaggingVC = [[ANProductViewTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:productTaggingVC animated:YES];
            }
                break;
            case 1: {
                ANAddToCartTaggingVC *addToCartVC = [[ANAddToCartTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:addToCartVC animated:YES];
            }
                break;
            case 2: {
                ANCheckoutTaggingVC *checkoutVC = [[ANCheckoutTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:checkoutVC animated:YES];
            }
                break;
            case 3: {
                ANCategoryViewTaggingVC *categoryTagVC = [[ANCategoryViewTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:categoryTagVC animated:YES];
            }
                break;
            case 4: {
                ANLandingPageTaggingVC *landingTagVC = [[ANLandingPageTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:landingTagVC animated:YES];
            }
                break;
            case 5: {
                ANSearchTermTaggingVC *searchTagVC = [[ANSearchTermTaggingVC alloc] initWithStyle:UITableViewStylePlain];
                [self.navigationController pushViewController:searchTagVC animated:YES];
            }
                break;
            default:
                break;
        }
    }
}

#pragma mark -
#pragma mark UITableViewDataSource methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

-(NSString *) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return @"Order Tracking";
        case 1:
            return @"Retargeting";
        default:
            return @"";
    }
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 3;
        case 1:
            return 6;
        default:
            return 0;
    }
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"DefaultCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    if(indexPath.section == 0) {
        switch (indexPath.row) {
            case 0: {
                cell.textLabel.text = @"Transaction Order Tracking";
            }
                break;
            case 1: {
                cell.textLabel.text = @"Basket Order Tracking";
            }
                break;
            case 2: {
                cell.textLabel.text = @"App Download Tracking";
            }
                break;
            default:
                break;
        }
    }
    if(indexPath.section == 1) {
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = @"Product View Tagging";
                break;
            case 1:
                cell.textLabel.text = @"Add To Cart Tagging";
                break;
            case 2:
                cell.textLabel.text = @"Checkout Tagging";
                break;
            case 3:
                cell.textLabel.text = @"Category Tagging";
                break;
            case 4:
                cell.textLabel.text = @"Landing Page Tagging";
                break;
            case 5:
                cell.textLabel.text = @"Search Page Tagging";
                break;
            default:
                break;
        }
    }
    
    return cell;
}

@end
