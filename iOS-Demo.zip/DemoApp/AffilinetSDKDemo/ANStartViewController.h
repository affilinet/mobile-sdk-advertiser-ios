//
//  ANStartViewController.h
//  AffilinetSDKDemo
//
//  Created by rabbit mobile GmbH on 29/10/13.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANStartViewController : UIViewController

@end
