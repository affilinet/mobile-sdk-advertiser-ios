//
//  ANRTOrderItem.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANRTProduct.h"

@interface ANRTOrderItem : NSObject

@property (nonatomic, strong) ANRTProduct *product;
@property (nonatomic, assign) NSInteger quantity;

@end
