//
//  ANAmountTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRetargetingTagging.h"
#import "ANCurrency.h"

#define kAN_PARAM_PRODUCT_ID @"product_id"
#define kAN_PARAM_PRODUCT_NAME @"product_name"
#define kAN_PARAM_PRODUCT_PRICE @"product_price"
#define kAN_PARAM_PRODUCT_OLD_PRICE @"product_oldprice"
#define kAN_PARAM_PRODUCT_CATEGORY @"product_category"
#define kAN_PARAM_PRODUCT_BRAND @"product_brand"
#define kAN_PARAM_PRODUCT_IN_STOCK @"product_inStock"
#define kAN_PARAM_PRODUCT_RATING @"product_rating"
#define kAN_PARAM_PRODUCT_ON_SALE @"product_onsale"
#define kAN_PARAM_PRODUCT_ACCESSORY @"product_accessory"
#define kAN_PARAM_PRODUCT_CLICK_URL @"product_clickUrl"
#define kAN_PARAM_PRODUCT_IMAGE_URL @"product_imgUrl"
#define kAN_PARAM_PRODUCT_QUANTITY @"product_quantity"

#define kAN_PARAM_CURRENCY @"currency"

#define kAN_PARAM_CUSTOMER_GENDER @"customer_gender"
#define kAN_PARAM_CUSTOMER_AGE_RANGE @"customer_agerange"
#define kAN_PARAM_CUSTOMER_ZIP @"customer_zip"

#define kAN_PARAM_USER_LOG @"user_log"

#define kAN_PARAM_TRAVEL_START_DATE @"travel_start_date"
#define kAN_PARAM_TRAVEL_END_DATE @"travel_end_date"
#define kAN_PARAM_TRAVEL_PRODUCT_TYPE @"travel_product_type"
#define kAN_PARAM_TRAVEL_KIDS @"travel_kids"
#define kAN_PARAM_TRAVEL_ADULTS @"travel_adults"
#define kAN_PARAM_TRAVEL_HOTEL_CATEGORY @"travel_hotel_category"
#define kAN_PARAM_TRAVEL_DEPARTURE @"travel_departure"
#define kAN_PARAM_TRAVEL_DESTINATION @"travel_destination"

@interface ANAmountTagging : ANRetargetingTagging

@property (nonatomic, strong) ANCurrency *currency;

@end
