//
//  ANCartViewTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANCartViewTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANCartViewTaggingHandler ()

@property (nonatomic, strong) ANCartViewTagging *cartViewTagging;

@end

@implementation ANCartViewTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct  *product = [[ANRTProduct alloc] init];
        // mandatory parameters
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        // optional parameters
        product.category = category;
        product.oldPrice = 42.99;
        product.brand = @"Amazing%20Brand";
        product.rating = 7;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        //mandatory parameters
        item1.quantity = 2;
        item1.product = product;
        
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        // mandatory parameters
        travelProduct.productId = @"replace-with-your-productid";
        travelProduct.name = @"Amazing%20Travel%20Product";
        travelProduct.price = 50.45;
        // optional parameters
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSinceNow:10];
        travelProduct.productType = @"with%20hotel";
        travelProduct.kids = NO;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"middle";
        travelProduct.pointOfDeparture = @"Lisbon";
        travelProduct.pointOfDestination = @"Frankfurt";
        travelProduct.category = category;
        
        ANRTOrderItem *item2 = [[ANRTOrderItem alloc] init];
        // mandatory parameters
        item2.quantity = 1;
        item2.product = travelProduct;
        
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        // mandatory parameters
        datingProduct.productId = @"replace-with-your-productid";
        datingProduct.name = @"Amazing%20Dating%20Product";
        datingProduct.price = 60.45;
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        // optional parameters
        customer.gender = @"male";
        customer.ageRange = @"25-50";
        customer.zipCode = @"80637";
        datingProduct.customer = customer; 
        
        ANRTOrderItem *item3 = [[ANRTOrderItem alloc] init];
        // mandatory parameters 
        item3.quantity = 1;
        item3.product = datingProduct;
        
        self.cartViewTagging = [[ANCartViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.cartViewTagging.items = @[item1, item2, item3];
        self.cartViewTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.cartViewTagging.total = 400.00;
        self.cartViewTagging.tax = 80.00;
        self.cartViewTagging.voucherCode = @"ChristmasSpecial01";
        self.cartViewTagging.voucherCodeDiscount = 10;
        
        self.requests = @[self.cartViewTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
