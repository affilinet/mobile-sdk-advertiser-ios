//
//  ANProductViewTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANProductViewTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANProductViewTaggingHandler ()

@property(nonatomic, strong) ANProductViewTagging *productTagging;
@property(nonatomic, strong) ANProductViewTagging *datingTagging;
@property(nonatomic, strong) ANProductViewTagging *travelTagging;

@end

@implementation ANProductViewTaggingHandler

-(id) init {
    self = [super init];
    if(self) {

        // Create standard retail product
        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct *product = [[ANRTProduct alloc] init];
        //mandatory parameters
        product.productId = @"replace-with-your-productid";
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        
        // optional parameters
        product.category = category;
        product.oldPrice = 42.99;
        product.brand = @"Amazing%20Brand";
        product.rating = 7;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        
        self.productTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.productTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.productTagging.product = product;

        // Create dating product
        ANRTProductCategory *categoryDating = [[ANRTProductCategory alloc] init];
        categoryDating.pathItems = @[@"Dating", @"Germany", @"25-50"];
        
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        // mandatory parameters
        datingProduct.productId = [NSString stringWithFormat:@"dating-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        datingProduct.name = @"Amazing%20Dating%20Product";
        datingProduct.price = 60.45;
        
        // optional parameters
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        customer.gender = @"male";
        customer.ageRange = @"18-25";
        customer.zipCode = @"60329";
        customer.wasLoggedIn = NO;
        customer.age = 22;
        customer.status = @"new";
        customer.country = @"Germany";
        datingProduct.customer = customer;
        datingProduct.category = categoryDating;
        
        self.datingTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.datingTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.datingTagging.product = datingProduct;
        
        // Create travel product
        ANRTProductCategory *categoryTravel = [[ANRTProductCategory alloc] init];
        categoryTravel.pathItems = @[@"Lastminute", @"Beach", @"Portugal"];
        
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        // mandatory parameters
        travelProduct.productId = [NSString stringWithFormat:@"travel-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        travelProduct.name = @"Amazing%20Travel%20Product";
        travelProduct.price = 50.45;
        
        // optional parameters
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSinceNow:10];
        travelProduct.productType = @"with%20hotel";
        travelProduct.kids = NO;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"middle";
        travelProduct.pointOfDeparture = @"Lisbon";
        travelProduct.pointOfDestination = @"Frankfurt";
        travelProduct.category = categoryTravel;
        
        self.travelTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.travelTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.travelTagging.product = travelProduct;
        
        self.requests = @[self.productTagging, self.datingTagging, self.travelTagging];
    }
    
    return self;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 12;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    switch (indexPath.row) {
        case 0: {
            cell.textLabel.text = @"Product ID";
            cell.detailTextLabel.text = self.productTagging.product.productId;
        }
            break;
        case 1: {
            cell.textLabel.text = @"Product Name";
            cell.detailTextLabel.text = self.productTagging.product.name;
        }
            break;
        case 2: {
            cell.textLabel.text = @"Price";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.productTagging.product.price];
        }
            break;
        case 3: {
            cell.textLabel.text = @"Old Price";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.productTagging.product.oldPrice];
        }
            break;
        case 4: {
            cell.textLabel.text = @"Currency";
            cell.detailTextLabel.text = [self.productTagging.currency stringValue];
        }
            break;
        case 5: {
            cell.textLabel.text = @"Brand";
            cell.detailTextLabel.text = self.productTagging.product.brand;
        }
            break;
        case 6: {
            cell.textLabel.text = @"Rating";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.productTagging.product.rating];
        }
            break;
        case 7: {
            cell.textLabel.text = @"In Stock";
            cell.detailTextLabel.text = self.productTagging.product.inStock ? @"Yes" : @"No";
        }
            break;
        case 8: {
            cell.textLabel.text = @"On Sale";
            cell.detailTextLabel.text = self.productTagging.product.onSale ? @"Yes" : @"No";
        }
            break;
        case 9: {
            cell.textLabel.text = @"Accessory";
            cell.detailTextLabel.text = self.productTagging.product.accessory ? @"Yes" : @"No";
        }
            break;
        case 10: {
            cell.textLabel.text = @"Click Url";
            cell.detailTextLabel.text = self.productTagging.product.clickURL;
        }
            break;
        case 11: {
            cell.textLabel.text = @"Image Url";
            cell.detailTextLabel.text = self.productTagging.product.imageURL;
        }
            break;
        default:
            break;
    }
    
    return cell;
}

@end
