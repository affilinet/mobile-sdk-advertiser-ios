//
//  ANProductViewTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANProductViewTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANProductViewTaggingHandler ()

@property(nonatomic, strong) ANProductViewTagging *productTagging;
@property(nonatomic, strong) ANProductViewTagging *datingTagging;
@property(nonatomic, strong) ANProductViewTagging *travelTagging;

@end

@implementation ANProductViewTaggingHandler

-(id) init {
    self = [super init];
    if(self) {

        // Create standard retail product
        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct *product = [[ANRTProduct alloc] init];
        //mandatory parameters
        product.productId = @"replace-with-your-productid";
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        
        // optional parameters
        product.category = category;
        product.oldPrice = 42.99;
        product.brand = @"Amazing%20Brand";
        product.rating = 7;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        
        self.productTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.productTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.productTagging.product = product;

        // Create dating product
        ANRTProductCategory *categoryDating = [[ANRTProductCategory alloc] init];
        categoryDating.pathItems = @[@"Dating", @"Germany", @"25-50"];
        
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        // mandatory parameters
        datingProduct.productId = [NSString stringWithFormat:@"dating-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        datingProduct.name = @"Amazing%20Dating%20Product";
        datingProduct.price = 60.45;
        
        // optional parameters
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        customer.gender = @"male";
        customer.ageRange = @"18-25";
        customer.zipCode = @"60329";
        customer.wasLoggedIn = NO;
        customer.age = 22;
        customer.status = @"new";
        customer.country = @"Germany";
        datingProduct.customer = customer;
        datingProduct.category = categoryDating;
        
        self.datingTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.datingTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.datingTagging.product = datingProduct;
        
        // Create travel product
        ANRTProductCategory *categoryTravel = [[ANRTProductCategory alloc] init];
        categoryTravel.pathItems = @[@"Lastminute", @"Beach", @"Portugal"];
        
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        // mandatory parameters
        travelProduct.productId = [NSString stringWithFormat:@"travel-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        travelProduct.name = @"Amazing%20Travel%20Product";
        travelProduct.price = 50.45;
        
        // optional parameters
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSinceNow:10];
        travelProduct.productType = @"with%20hotel";
        travelProduct.kids = NO;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"middle";
        travelProduct.pointOfDeparture = @"Lisbon";
        travelProduct.pointOfDestination = @"Frankfurt";
        travelProduct.category = categoryTravel;
        
        self.travelTagging = [[ANProductViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.travelTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.travelTagging.product = travelProduct;
        
        self.requests = @[self.productTagging, self.datingTagging, self.travelTagging];
    }
    
    return self;
}

@end
