//
//  ANSaleTrackingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 07/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANSaleTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANSaleTrackingHandler ()

@property (nonatomic, strong) ANSaleTracking *saleTracking;

@end

@implementation ANSaleTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.saleTracking = [[ANSaleTracking alloc] initWithSession:[ANSession sharedInstance]];
         self.saleTracking.adType = [[ANOTOrderAdType alloc] initWithAdNumber:1 andAdType:kANAdTypeGraphicBanner];
         self.saleTracking.voucherCode = @"test-vCode";
         self.saleTracking.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
         self.saleTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeSale];
        self.saleTracking.order = [[ANRTOrder alloc] init];
        self.saleTracking.order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.saleTracking.order.total = 400;
        self.saleTracking.order.orderDescription = @"order description";
        self.saleTracking.order.orderDate = [NSDate date];
        [self.saleTracking addProgramSubID:@"example1"];
        [self.saleTracking addProgramSubID:@"example2"];

         self.requests = @[self.saleTracking];
    }
    return self;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 11;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    /*
     switch (indexPath.row) {
     case 0: {
     cell.textLabel.text = @"Order ID";
     cell.detailTextLabel.text = self.orderTracking.orderID;
     }
     break;
     case 1: {
     cell.textLabel.text = @"Media Type";
     cell.detailTextLabel.text = [self.orderTracking.mediaType stringValue];
     }
     break;
     case 2: {
     cell.textLabel.text = @"Media Number";
     cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.orderTracking.mediaType.mediaNumber];
     }
     break;
     case 3: {
     cell.textLabel.text = @"Voucher Code";
     cell.detailTextLabel.text = self.orderTracking.vCode;
     }
     break;
     case 4: {
     cell.textLabel.text = @"Currency";
     cell.detailTextLabel.text = [self.orderTracking.currency stringValue];
     }
     break;
     case 5: {
     cell.textLabel.text = @"Order Value";
     cell.detailTextLabel.text = [NSString stringWithFormat:@"%.02f", self.orderTracking.orderValue];
     }
     break;
     case 6: {
     cell.textLabel.text = @"Rate Mode";
     cell.detailTextLabel.text = [self.orderTracking.orderRate stringValue];
     }
     break;
     case 7: {
     cell.textLabel.text = @"Rate Number";
     cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", (long)self.orderTracking.orderRate.rateNumber];
     }
     break;
     case 8: {
     cell.textLabel.text = @"Sub";
     cell.detailTextLabel.text = @"";
     for(NSString * sub in self.orderTracking.pSub) {
     cell.detailTextLabel.text = [cell.detailTextLabel.text stringByAppendingFormat:@" %@", sub];
     }
     }
     break;
     default:
     break;
     }
     */
    return cell;
}
@end
