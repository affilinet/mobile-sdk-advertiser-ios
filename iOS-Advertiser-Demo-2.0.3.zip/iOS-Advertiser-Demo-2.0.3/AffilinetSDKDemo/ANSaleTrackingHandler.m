//
//  ANSaleTrackingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 07/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANSaleTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANSaleTrackingHandler ()

@property (nonatomic, strong) ANSaleTracking *saleTracking;

@end

@implementation ANSaleTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.saleTracking = [[ANSaleTracking alloc] initWithSession:[ANSession sharedInstance]];
        // mandatory parameters
        self.saleTracking.order = [[ANRTOrder alloc] init];
        self.saleTracking.order.orderId = @"custom-order-id";
        self.saleTracking.order.total = 400;
        self.saleTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeSale]; // Please replace rate number which applies to the sale
        
        // optional parameters
        [self.saleTracking addProgramSubID:@"custom-program-subid1"];
        [self.saleTracking addProgramSubID:@"custom-program-subid2"];
        self.saleTracking.voucherCode = @"TEST";
        self.saleTracking.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.saleTracking.order.orderDescription = @"custom-order-description";
        self.saleTracking.order.orderDate = [NSDate date];

        self.requests = @[self.saleTracking];
    }
    return self;
}

@end
