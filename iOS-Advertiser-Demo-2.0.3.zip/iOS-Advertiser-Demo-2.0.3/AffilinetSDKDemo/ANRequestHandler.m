//
//  ANRequestHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANRequestHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANRequestHandler ()

@end

@implementation ANRequestHandler

- (id)init
{
    self = [super init];
    if (self) {
    }
    return self;
}

-(void) doRequest {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    ANSession *session = [ANSession sharedInstance];
    session.onRequestResponse = ^(ANRequest *request, ANRequestResponse *response) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        if(response.error != nil) {
            NSLog(@"Request Finished with Error: %@", response.error.localizedDescription);
        }
        else {
            NSLog(@"Request Finished");
        }
    };

    session.onRequestsError = ^(NSError *error) {
        NSLog(@"Requests error: %@", [error domain]);
    };
    
    [session executeRequests:self.requests];
}

@end
