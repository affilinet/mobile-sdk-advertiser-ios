//
//  ANAddToCartTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANAddToCartTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANAddToCartTaggingHandler ()

@property (nonatomic, strong) ANAddToCartTagging *addToCart;

@end

@implementation ANAddToCartTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        self.addToCart = [[ANAddToCartTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.addToCart.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        
        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct  *product = [[ANRTProduct alloc] init];
        // mandatory parameters
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        
        // optional parameters
        product.category = category;
        product.oldPrice = 42.99;
        product.brand = @"Amazing%20Brand";
        product.rating = 7;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        
        ANRTOrderItem *item = [[ANRTOrderItem alloc] init];
        // mandatory parameters 
        item.product = product;
        item.quantity = 2;
        
        self.addToCart.item = item;
        
        self.requests = @[self.addToCart];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
