//
//  ANTransactionOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANOrderTracking.h"
#import "ANOTOrderRate.h"

#define kAN_PARAM_PRICE @"price"
#define kAN_PARAM_MODE @"mode"
#define kAN_PARAM_LTYPE @"ltype"

@interface ANTransactionOrderTracking : ANOrderTracking <ANHTMLRequestDelegate>

@property (nonatomic, assign) double orderValue;
@property (nonatomic, strong) ANOTOrderRate *orderRate;

@end
