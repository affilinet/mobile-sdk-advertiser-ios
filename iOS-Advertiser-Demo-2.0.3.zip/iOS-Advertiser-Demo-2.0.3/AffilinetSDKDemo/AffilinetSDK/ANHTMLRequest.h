//
//  ANHTMLRequest.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRequest.h"
#import "GDataXMLNode.h"

#define kAN_ENDPOINT_REGISTER_SALE @"/registersale.asp"
#define kAN_ENDPOINT_DEVICE_TRACKING @"/art/JS/param.aspx"

@protocol ANHTMLRequestDelegate <NSObject>

-(BOOL) isValid:(ANSession *) session withError:(NSError **)error;
-(GDataXMLElement *) buildHtmlDocument:(ANSession *) session;

@end

@interface ANHTMLRequest : ANRequest

-(NSArray *) getHtmlElements:(NSError **)error;

@end
