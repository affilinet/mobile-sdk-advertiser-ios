//
//  AffilinetSDK.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AffilinetSDK : NSObject

@end
