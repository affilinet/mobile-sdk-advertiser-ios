//
//  ANSearchTermTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANSearchTermTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANSearchTermTaggingHandler ()

@property (nonatomic, strong) ANSearchPageTagging *searchTag;

@end

@implementation ANSearchTermTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        self.searchTag = [[ANSearchPageTagging alloc] initWithSession:[ANSession sharedInstance]];
        //self.searchTag.searchTerm = @"Search Term"; //deprecated
        self.searchTag.keywords = @[@"Search Term 1", @"Search Term 2"];
        
        ANRTProduct *product1 = [[ANRTProduct alloc] init];
        product1.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        
        ANRTProduct *product2 = [[ANRTProduct alloc] init];
        product2.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        
        self.searchTag.products = @[product1, product2];
        
        [[ANSession sharedInstance] setOnRequestResponse:^(ANRequest *request, ANRequestResponse *response) {
            if(response.error != nil) {
                NSLog(@"Request %@ finished with error %@", request, response.error);
            }
            else {
                NSLog(@"Request %@ finished with response %@", request, response);
            }
        }];
        
        [[ANSession sharedInstance] setOnRequestsFinished:^{
            NSLog(@"Requests Finished");
        }];
        
        [[ANSession sharedInstance] setOnRequestsError:^(NSError *error) {
            NSLog(@"Requests finished with error: %@", error);
        }];
        
        self.requests = @[self.searchTag];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
