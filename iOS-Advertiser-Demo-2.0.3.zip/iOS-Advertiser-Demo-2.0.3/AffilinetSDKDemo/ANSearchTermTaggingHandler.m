//
//  ANSearchTermTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANSearchTermTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANSearchTermTaggingHandler ()

@property (nonatomic, strong) ANSearchPageTagging *searchTag;

@end

@implementation ANSearchTermTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.searchTag = [[ANSearchPageTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.searchTag.keywords = @[@"keyword%201", @"keyword%202"];
        self.searchTag.refererURL = @"http%3A%2F%2Fadvertiser.com";
        
        ANRTProduct *product1 = [[ANRTProduct alloc] init];
        product1.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        product1.name = @"name%201";
        
        ANRTProduct *product2 = [[ANRTProduct alloc] init];
        product2.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        product2.name = @"name%201";
        
        self.searchTag.products = @[product1, product2];
        
        [[ANSession sharedInstance] setOnRequestResponse:^(ANRequest *request, ANRequestResponse *response) {
            if(response.error != nil) {
                NSLog(@"Request %@ finished with error %@", request, response.error);
            }
            else {
                NSLog(@"Request %@ finished with response %@", request, response);
            }
        }];
        
        [[ANSession sharedInstance] setOnRequestsFinished:^{
            NSLog(@"Requests Finished");
        }];
        
        [[ANSession sharedInstance] setOnRequestsError:^(NSError *error) {
            NSLog(@"Requests finished with error: %@", error);
        }];
        
        self.requests = @[self.searchTag];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
