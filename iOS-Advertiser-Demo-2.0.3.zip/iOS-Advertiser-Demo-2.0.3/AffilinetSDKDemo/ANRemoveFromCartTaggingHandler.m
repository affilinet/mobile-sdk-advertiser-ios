//
//  ANRemoveFromCartTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANRemoveFromCartTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANRemoveFromCartTaggingHandler ()

@property (nonatomic, strong) ANRemoveFromCartTagging *removeFromCart;

@end

@implementation ANRemoveFromCartTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        self.removeFromCart = [[ANRemoveFromCartTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.removeFromCart.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];

        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct  *product = [[ANRTProduct alloc] init];
        // mandatory parameters
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        
        // optional parameters
        product.category = category;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        
        ANRTOrderItem *item = [[ANRTOrderItem alloc] init];
        // mandatory parameters 
        item.product = product;
        item.quantity = 1;
        
        self.removeFromCart.item = item;
        
        self.requests = @[self.removeFromCart];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
