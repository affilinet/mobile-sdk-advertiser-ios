//
//  ANRemoveFromCartTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANRemoveFromCartTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANRemoveFromCartTaggingHandler ()

@property (nonatomic, strong) ANRemoveFromCartTagging *removeFromCart;

@end

@implementation ANRemoveFromCartTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        self.removeFromCart = [[ANRemoveFromCartTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.removeFromCart.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        
        // standard product item
        ANRTProduct *product = [[ANRTProduct alloc] init];
        product.category = [[ANRTProductCategory alloc] init];
        product.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing Product";
        product.price = 5.43;
        product.oldPrice = 5.99;
        product.brand = @"Amazing Brand";
        product.rating = 3;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http://something-product.com";
        product.imageURL = @"http://something-product.com/image.png";
        
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        item1.quantity = 2;
        item1.product = product;
        
        self.removeFromCart.item = item1;
        
        self.requests = @[self.removeFromCart];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
