//
//  ANBasketTrackingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANBasketTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANBasketTrackingHandler ()

@property (nonatomic, strong) ANBasketTracking *basketTracking;

@end

@implementation ANBasketTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {

        ANOTBasketItem *basketItem1 = [[ANOTBasketItem alloc] init];
        // mandatory parameters
        basketItem1.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        basketItem1.quantity = 1;
        basketItem1.singlePrice = 20.45;
        // optional parameters
        basketItem1.productName = @"Amazing%20Product";
        basketItem1.category = @"jeans";
        basketItem1.brand = @"Versace";
        basketItem1.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
        basketItem1.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeSale];
        
        ANOTBasketItem *basketItem2 = [[ANOTBasketItem alloc] init];
        // mandatory parameters
        basketItem2.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        basketItem2.quantity = 3;
        basketItem2.singlePrice = 60.45;
        // optional parameters
        basketItem2.productName = @"Amazing%20Product%202";
        basketItem2.category = @"jeans%202";
        basketItem2.brand = @"Versace%202";
        basketItem2.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
        basketItem2.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeSale];

        
        self.basketTracking = [[ANBasketTracking alloc] initWithSession:[ANSession sharedInstance]];
        
        // mandatory parameters
        self.basketTracking.orderId = [NSString stringWithFormat:@"iOS-Basket-%@", (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        self.basketTracking.basketItems = @[basketItem1, basketItem2];
        
        // optional parameters
        self.basketTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeSale];
        self.basketTracking.voucherCode = @"TEST";
        self.basketTracking.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.basketTracking.orderDate = [NSDate date];
        [self.basketTracking addProgramSubID:@"custom-program-subid1"];
        [self.basketTracking addProgramSubID:@"custom-program-subid2"];
        self.basketTracking.orderId = [NSString stringWithFormat:@"iOS-Basket-%@", (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        self.basketTracking.orderDescription = @"custom-order-description";
        self.basketTracking.clickDate = [NSDate date];
        
        ANOTBasketItem *item1 = [[ANOTBasketItem alloc] init];
        item1.quantity = 2;
        item1.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item1.productName = @"Amazing Product 1";
        item1.singlePrice = 40.45;
        item1.properties = @[@"size_large",@"colour_green",@"style_bootCut"];
        item1.brand = @"brand1";
        item1.category = @"category";
        
        ANOTBasketItem *item2 = [[ANOTBasketItem alloc] init];
        item2.quantity = 4;
        item2.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item2.productName = @"Amazing Product 2";
        item2.singlePrice = 40.45;
        item2.properties = @[@"size_large",@"colour_green",@"style_bootCut"];
        item2.brand = @"brand1";
        item2.category = @"category";
        
        self.basketTracking.basketItems = @[item1, item2];

        self.requests = @[self.basketTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
