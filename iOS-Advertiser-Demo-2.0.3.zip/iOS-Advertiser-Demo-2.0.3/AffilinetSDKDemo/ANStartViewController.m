//
//  ANStartViewController.m
//  AffilinetSDKDemo
//
//  Created by Joao Santos on 29/10/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANStartViewController.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

#import "ANSaleTrackingHandler.h"
#import "ANProductViewTaggingHandler.h"
#import "ANAddToCartTaggingHandler.h"
#import "ANRemoveFromCartTaggingHandler.h"
#import "ANCartViewTaggingHandler.h"
#import "ANCheckoutTaggingHandler.h"
#import "ANBasketTrackingHandler.h"
#import "ANLeadTrackingHandler.h"
#import "ANCategoryViewTaggingHandler.h"
#import "ANPageTaggingHandler.h"
#import "ANSearchTermTaggingHandler.h"
@import WebKit;

@interface ANStartViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property ANRequestHandler *requestHandler;

@end

@implementation ANStartViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor grayColor];
        
        self.tableView = [[UITableView alloc] initWithFrame:(CGRect){{0,0}, self.view.frame.size} style:UITableViewStylePlain];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        [self.view addSubview:self.tableView];
        
        ANAdvertiserAccount *account = [[ANAdvertiserAccount alloc] init];
#warning TODO: add your program-id
        account.accountIDs = @[/*@PROGRAM-ID*/];
        [[ANSession sharedInstance] openWithAccount:account andCountryCode:ANCountryCodeDE];
        
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //Simulating a tracked interaction to enable future attribution
    if ([((ANSession *)[ANSession sharedInstance]).account.formattedAccountID length] > 2) {//prevents crashing before account ID has been entered in this demo
        WKWebView *webview = [[WKWebView alloc] initWithFrame:self.view.frame];
        webview.hidden = YES;
        [self.view addSubview:webview];
        NSString *trackingURL = [NSString stringWithFormat:@"http://%@/click.asp?ref=%@&site=%ld&type=text&tnb=2", [((ANSession *)[ANSession sharedInstance]).platform domain], [self demoClickRef], (long)[((ANSession *)[ANSession sharedInstance]).account formattedAccountID]];
        [webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:trackingURL]]];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark UITableViewDelegate methods

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0) {
        switch (indexPath.row) {
            case 0: {
                self.requestHandler = [[ANSaleTrackingHandler alloc] init];
            }
                break;
            case 1: {
                self.requestHandler = [[ANBasketTrackingHandler alloc] init];
            }
                break;
            case 2: {
                self.requestHandler = [[ANLeadTrackingHandler alloc] init];
            }
                break;
            default:
                break;
        }
    }
    else if(indexPath.section == 1) {
        switch (indexPath.row) {
            case 0: {
                self.requestHandler = [[ANProductViewTaggingHandler alloc] init];
            }
                break;
            case 1: {
                self.requestHandler = [[ANAddToCartTaggingHandler alloc] init];
            }
                break;
            case 2: {
                self.requestHandler = [[ANRemoveFromCartTaggingHandler alloc] init];
            }
                break;
            case 3: {
                self.requestHandler = [[ANCartViewTaggingHandler alloc] init];
            }
                break;
            case 4: {
                self.requestHandler = [[ANCheckoutTaggingHandler alloc] init];
            }
                break;
            case 5: {
                self.requestHandler = [[ANCategoryViewTaggingHandler alloc] init];
            }
                break;
            case 6: {
                self.requestHandler = [[ANPageTaggingHandler alloc] init];
            }
                break;
            case 7: {
                self.requestHandler = [[ANSearchTermTaggingHandler alloc] init];
            }
                break;
            default:
                break;
        }
    }
    
    if (self.requestHandler) {
        [self.requestHandler doRequest];
    }
}

#pragma mark -
#pragma mark UITableViewDataSource methods

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

-(NSString *) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return @"Order Tracking";
        case 1:
            return @"Profiling";
        default:
            return @"";
    }
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 3;
        case 1:
            return 8;
        default:
            return 0;
    }
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"DefaultCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    if(indexPath.section == 0) {
        switch (indexPath.row) {
            case 0: {
                cell.textLabel.text = @"Sale Tracking";
            }
                break;
            case 1: {
                cell.textLabel.text = @"Basket Order Tracking";
            }
                break;
            case 2: {
                cell.textLabel.text = @"Lead Tracking";
            }
                break;
            default:
                break;
        }
    }
    if(indexPath.section == 1) {
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = @"Product View Tagging";
                break;
            case 1:
                cell.textLabel.text = @"Add To Cart Tagging";
                break;
            case 2:
                cell.textLabel.text = @"Remove From Cart Tagging";
                break;
            case 3:
                cell.textLabel.text = @"Cart View Tagging";
                break;
            case 4:
                cell.textLabel.text = @"Checkout Tagging";
                break;
            case 5:
                cell.textLabel.text = @"Category Tagging";
                break;
            case 6:
                cell.textLabel.text = @"Page View Tagging";
                break;
            case 7:
                cell.textLabel.text = @"Search Page Tagging";
                break;
            default:
                break;
        }
    }
    
    return cell;
}

#pragma mark -
#pragma mark Demo specific helper methods

-(NSString *) demoClickRef {
    NSString *locale = [((ANSession *)[ANSession sharedInstance]).platform stringValue];
    if ([locale isEqualToString:@"DE"]) {
        return @"651";
    }
    if ([locale isEqualToString:@"AT"]) {
        return @"752";
    }
    if ([locale isEqualToString:@"FR"]) {
        return @"387960";
    }
    if ([locale isEqualToString:@"CH"]) {
        return @"705";
    }
    if ([locale isEqualToString:@"GB"]) {
        return @"236725";
    }
    if ([locale isEqualToString:@"ES"]) {
        return @"387963";
    }
    if ([locale isEqualToString:@"NL"]) {
        return @"387962";
    }
    return @"";
}

@end
