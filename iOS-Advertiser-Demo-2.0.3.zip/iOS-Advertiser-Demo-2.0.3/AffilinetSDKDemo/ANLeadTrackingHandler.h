//
//  ANLeadTrackingHandler.h
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 01/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANRequestHandler.h"

@interface ANLeadTrackingHandler : ANRequestHandler

@end
