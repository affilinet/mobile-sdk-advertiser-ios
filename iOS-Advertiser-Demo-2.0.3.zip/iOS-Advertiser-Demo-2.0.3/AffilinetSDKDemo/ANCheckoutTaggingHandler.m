//
//  ANCheckoutTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANCheckoutTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANCheckoutTaggingHandler ()

@property (nonatomic, strong) ANCheckoutTagging *checkoutTagging;

@end

@implementation ANCheckoutTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        self.checkoutTagging = [[ANCheckoutTagging alloc] initWithSession:[ANSession sharedInstance]];
        
        self.checkoutTagging.publisherID = 784108;
        self.checkoutTagging.order = [[ANRTOrder alloc] init];
        self.checkoutTagging.order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.checkoutTagging.order.total = 400;
        self.checkoutTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        item1.quantity = 2;
        item1.product = [[ANRTProduct alloc] init];
        item1.product.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item1.product.name = @"Amazing Product 1";
        item1.product.price = 40.45;
        item1.product.oldPrice = 40.45;
        
        ANRTOrderItem *item2 = [[ANRTOrderItem alloc] init];
        item2.quantity = 1;
        item2.product = [[ANRTTravelProduct alloc] init];
        item2.product.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item2.product.name = @"Amazing Product 2";
        item2.product.price = 13.45;
        item2.product.oldPrice = 14.98;
        ((ANRTTravelProduct *)item2.product).departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        ((ANRTTravelProduct *)item2.product).endDate = [NSDate dateWithTimeIntervalSinceNow:0];
        ((ANRTTravelProduct *)item2.product).productType = @"flight-only";
        ((ANRTTravelProduct *)item2.product).kids = NO;
        ((ANRTTravelProduct *)item2.product).numberOfAdults = 2;
        ((ANRTTravelProduct *)item2.product).hotelCategory = @"NA";
        ((ANRTTravelProduct *)item2.product).pointOfDeparture = @"Lisbon";
        ((ANRTTravelProduct *)item2.product).pointOfDestination = @"Frankfurt";
        
        ANRTDatingCustomer *datingCustomer = [[ANRTDatingCustomer alloc] init];
        datingCustomer.gender = @"male";
        datingCustomer.ageRange = @"18-25";
        datingCustomer.zipCode = @"60329";
        datingCustomer.wasLoggedIn = NO;
        datingCustomer.age = 22;
        datingCustomer.status = @"new";
        datingCustomer.country = @"Germany";
        self.checkoutTagging.datingCustomer = datingCustomer;
        
        self.checkoutTagging.order.items = @[item1, item2];
        
        self.requests = @[self.checkoutTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
