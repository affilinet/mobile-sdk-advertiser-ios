//
//  ANCheckoutTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANCheckoutTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANCheckoutTaggingHandler ()

@property (nonatomic, strong) ANCheckoutTagging *checkoutTagging;

@end

@implementation ANCheckoutTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        
        ANRTProductCategory *category = [[ANRTProductCategory alloc] init];
        category.pathItems = @[@"Clothes", @"Shoes", @"Flip%20Flops"];
        
        ANRTProduct  *product = [[ANRTProduct alloc] init];
        // mandatory parameters
        product.productId = @"replace-with-your-productid";
        product.name = @"Amazing%20Product";
        product.price = 40.45;
        // optional parameters
        product.category = category;
        product.clickURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fclick.html";
        product.imageURL = @"http%3A%2F%2Fadvertiser.com%2Fproduct%2Fimage.png";
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        //mandatory parameters
        item1.quantity = 2;
        item1.product = product;
        
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        // mandatory parameters
        travelProduct.productId = @"replace-with-your-productid";
        travelProduct.name = @"Amazing%20Travel%20Product";
        travelProduct.price = 50.45;
        // optional parameters
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSinceNow:10];
        travelProduct.productType = @"with%20hotel";
        travelProduct.kids = NO;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"middle";
        travelProduct.pointOfDeparture = @"Lisbon";
        travelProduct.pointOfDestination = @"Frankfurt";
        travelProduct.category = category;
        ANRTOrderItem *item2 = [[ANRTOrderItem alloc] init];
        // mandatory parameters
        item2.quantity = 1;
        item2.product = travelProduct;
        
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        // mandatory parameters
        datingProduct.productId = @"replace-with-your-productid";
        datingProduct.name = @"Amazing%20Dating%20Product";
        datingProduct.price = 60.45;
        ANRTOrderItem *item3 = [[ANRTOrderItem alloc] init];
        //mandatory parameters 
        item3.quantity = 1;
        item3.product = datingProduct;
		
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        // optional parameters 
        customer.gender = @"male";
		customer.ageRange = @"25-50";
		customer.age = 39;
		customer.country = @"Germany";
		customer.zipCode = @"80637";
		customer.status = @"new";
        customer.wasLoggedIn = NO;

        ANRTOrder *order = [[ANRTOrder alloc] init];
        order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        order.total = 201.80;
        order.items = @[item1, item2, item3];
        
        self.checkoutTagging = [[ANCheckoutTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.checkoutTagging.order = order;
        self.checkoutTagging.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.checkoutTagging.datingCustomer = customer;
        
        self.requests = @[self.checkoutTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
