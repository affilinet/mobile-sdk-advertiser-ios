//
//  ANAppDownloadTrackingHandler.h
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 22/08/2017.
//  Copyright © 2017 affilinet. All rights reserved.
//

#import "ANRequestHandler.h"

#define kNamespacedKey @"com.namespaced.key"

@interface ANAppDownloadTrackingHandler : ANRequestHandler

@end
