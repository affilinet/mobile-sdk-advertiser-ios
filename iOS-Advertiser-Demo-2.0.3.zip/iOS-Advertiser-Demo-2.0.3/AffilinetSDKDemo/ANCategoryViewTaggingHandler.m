//
//  ANCategoryViewTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANCategoryViewTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANCategoryViewTaggingHandler ()

@property (nonatomic, strong) ANCategoryViewTagging *categoryTagging;

@end

@implementation ANCategoryViewTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.categoryTagging = [[ANCategoryViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.categoryTagging.category = [[ANRTProductCategory alloc] init];
        self.categoryTagging.category.categoryId = [NSString stringWithFormat:@"iOS-Category-%@", (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        self.categoryTagging.category.name = @"Category Name";
        self.categoryTagging.category.clickURL = @"http://clickurl.com";
        self.categoryTagging.category.imageURL = @"http://imageurl.com";
        
        self.requests = @[self.categoryTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
