//
//  ANAppDownloadTrackingHandler.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 22/08/2017.
//  Copyright © 2017 affilinet. All rights reserved.
//

#import "ANAppDownloadTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANAppDownloadTrackingHandler ()

@property (nonatomic, strong) ANLeadTracking *leadTracking;

@end

@implementation ANAppDownloadTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.leadTracking = [[ANLeadTracking alloc] initWithSession:[ANSession sharedInstance]];
        
        // mandatory parameters
        self.leadTracking.order = [[ANRTOrder alloc] init];
        self.leadTracking.order.orderId = @"custom-app-download-id";
        self.leadTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1
                                                                    andRateMode:OTOrderRateModeLead];
        
        // optional parameters
        [self.leadTracking addProgramSubID:@"custom-program-subid1"];
        [self.leadTracking addProgramSubID:@"custom-program-subid2"];
        self.leadTracking.order.orderDescription = @"app-download-description";
        self.leadTracking.lmulti = 1;
        
        self.requests = @[self.leadTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) doRequest {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    ANSession *session = [ANSession sharedInstance];
    session.onRequestResponse = ^(ANRequest *request, ANRequestResponse *response) {
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        if(response.error != nil) {
            NSLog(@"Request Finished with Error: %@", response.error.localizedDescription);
        } else {
            NSLog(@"Request Finished");
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            [userDefaults setBool:YES
                           forKey:kNamespacedKey];
            [userDefaults synchronize];
        }
    };
    
    session.onRequestsError = ^(NSError *error) {
        NSLog(@"Requests error: %@", [error domain]);
    };
    
    [session executeRequests:self.requests];
}

@end
