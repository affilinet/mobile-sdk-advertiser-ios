//
//  ANCheckoutTaggingHandler.h
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANRequestHandler.h"

@interface ANCheckoutTaggingHandler : ANRequestHandler

@end
