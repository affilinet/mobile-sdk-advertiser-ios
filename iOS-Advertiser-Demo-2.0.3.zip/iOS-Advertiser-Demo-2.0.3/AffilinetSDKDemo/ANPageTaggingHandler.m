//
//  ANPageTaggingHandler.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANPageTaggingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANPageTaggingHandler ()

//@property (nonatomic, strong) ANLandingpageTagging *landingTagging; //deprecated
@property (nonatomic, strong) ANPageViewTagging *pageViewTagging;

@end

@implementation ANPageTaggingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.pageViewTagging = [[ANPageViewTagging alloc] initWithSession:[ANSession sharedInstance]];
        
        // mandatory parameters
        self.pageViewTagging.pageName = @"pageName";
        
        // optional parameters
        self.pageViewTagging.pageCategory = @"pageCategory";
        self.pageViewTagging.pageType = @"pageType";
        self.pageViewTagging.pageURL = @"pageUrl";
        self.pageViewTagging.refererURL = @"http%3A%2F%2Fadvertiser.com";
        
        self.requests = @[self.pageViewTagging];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
