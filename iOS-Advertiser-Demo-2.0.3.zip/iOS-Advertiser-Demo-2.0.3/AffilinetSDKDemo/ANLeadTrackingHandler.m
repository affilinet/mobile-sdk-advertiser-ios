//
//  ANLeadTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 01/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANLeadTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANLeadTrackingHandler ()

@property (nonatomic, strong) ANLeadTracking *leadTracking;

@end

@implementation ANLeadTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.leadTracking = [[ANLeadTracking alloc] initWithSession:[ANSession sharedInstance]];
        
        // mandatory parameters
        self.leadTracking.order = [[ANRTOrder alloc] init];
        self.leadTracking.order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.leadTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeLead]; // Please replace rate number which applies to the lead
        
        // optional parameters
        self.leadTracking.order.total = 400;
        [self.leadTracking addProgramSubID:@"custom-program-subid1"];
        [self.leadTracking addProgramSubID:@"custom-program-subid2"];
        self.leadTracking.voucherCode = @"TEST";
        self.leadTracking.currency = [[ANCurrency alloc] initWithStringCode:kCurrencyCodeEUR];
        self.leadTracking.order.orderDescription = @"custom-order-description";
        self.leadTracking.order.orderDate = [NSDate date];
        //self.leadTracking.lmulti = 1;
        
        self.requests = @[self.leadTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
