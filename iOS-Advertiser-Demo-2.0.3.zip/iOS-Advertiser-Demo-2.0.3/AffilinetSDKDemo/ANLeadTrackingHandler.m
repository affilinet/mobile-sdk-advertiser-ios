//
//  ANLeadTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 01/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANLeadTrackingHandler.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANLeadTrackingHandler ()

@property (nonatomic, strong) ANLeadTracking *leadTracking;

@end

@implementation ANLeadTrackingHandler

- (id)init
{
    self = [super init];
    if (self) {
        self.leadTracking = [[ANLeadTracking alloc] initWithSession:[ANSession sharedInstance]];
        self.leadTracking.orderRate = [[ANOTOrderRate alloc] initWithRateNumber:1 andRateMode:OTOrderRateModeLead];
        self.leadTracking.lmulti = 4;
        self.leadTracking.order = [[ANRTOrder alloc] init];
        self.leadTracking.order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.leadTracking.order.total = 400;
        self.leadTracking.order.orderDescription = @"order description";
        self.leadTracking.order.orderDate = [NSDate date];
        [self.leadTracking addProgramSubID:@"example1"];
        [self.leadTracking addProgramSubID:@"example2"];
        
        self.requests = @[self.leadTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
