//
//  ANPageViewTagging.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 26/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANACTTagging.h"

@interface ANPageViewTagging : ANACTTagging

@property(nonatomic, strong) NSString *pageURL;
@property(nonatomic, strong) NSString *pageType;
@property(nonatomic, strong) NSString *pageName;
@property(nonatomic, strong) NSString *pageCategory;
@property(nonatomic, strong) NSString *refererURL;

@end
