//
//  ANRequestResponse.h
//  AffilinetSDK
//
//  Created by Joao Santos on 28/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANRequestResponse : NSOperation

@property (nonatomic, strong) NSError *error;
@property (nonatomic, strong) NSString *rawResponse;

@end
