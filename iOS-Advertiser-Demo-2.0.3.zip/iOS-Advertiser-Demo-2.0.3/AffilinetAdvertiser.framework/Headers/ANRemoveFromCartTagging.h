//
//  ANRemoveFromCartTagging.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrderItem.h"

@interface ANRemoveFromCartTagging : ANAmountTagging

@property (nonatomic, strong) ANRTOrderItem *item;
@property(nonatomic, strong) NSString *refererURL;

@end
