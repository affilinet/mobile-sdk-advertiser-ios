//
//  ANWebserviceResponse+ANJsonMapper.h
//  AffilinetSDK
//
//  Created by João Santos on 16/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANWebserviceResponse.h"
#import "ANJsonMapper.h"

@interface ANWebserviceResponse (ANJsonMapper)

-(void) mergeParamsFromJsonMapper:(ANJsonMapper *)mapper;

@end
