//
//  ANACTTagging.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 26/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"

#define encodeString(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString255(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 255 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:255] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString80(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 80 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:80] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString25(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 25 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:25] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString30(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 30 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:30] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString40(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 40 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:40] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]
#define encodeString50(str) [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]].length > 50 ? [[str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]] substringToIndex:50] : [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]

#define stringNotNull(str) (str ? str : @"(null)")

#define encodeBool(bool) (bool ? @"true" : @"false")
#define encodeArray(array) [NSString stringWithFormat:@"['%@']", [[array componentsJoinedByString:@"','"] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLHostAllowedCharacterSet]]]

#define kAN_PARAM_REFERER_URL @"referer_url"
#define kAN_PARAM_PAGE_URL @"page_url"
#define kAN_PARAM_PAGE_TYPE @"page_type"
#define kAN_PARAM_PAGE_NAME @"page_name"
#define kAN_PARAM_PAGE_CATEGORY @"page_category"

#define kAN_PARAM_CATEGORY_ID @"category_id"
#define kAN_PARAM_CATEGORY_NAME @"category_name"
#define kAN_PARAM_CATEGORY_IMAGE_URL @"category_img_url"
#define kAN_PARAM_CATEGORY_CLICK_URL @"category_click_url"

#define kAN_PARAM_SEARCH_KEYWORDS @"search_keywords"
#define kAN_PARAM_PRODUCT_IDS @"product_ids"

@interface ANACTTagging : ANHTMLRequest <ANHTMLRequestDelegate>

@end
