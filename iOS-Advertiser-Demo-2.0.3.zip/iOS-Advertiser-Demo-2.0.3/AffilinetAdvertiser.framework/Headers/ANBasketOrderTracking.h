//
//  ANBasketOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANOrderTracking.h"

__deprecated_msg("ANBasketOrderTracking is deprecated please use ANBasketTracking instead.")
@interface ANBasketOrderTracking : ANOrderTracking <ANHTMLRequestDelegate>

@property(nonatomic, strong) NSMutableArray *items;

@end
