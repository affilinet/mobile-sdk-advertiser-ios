//
//  ANGetProductsRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANProductsRequest.h"

@interface ANGetProductsRequest : ANProductsRequest

@property (nonatomic, strong) NSArray *productIds;

@end
