//
//  ANSaleTracking.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANACTOrderTracking.h"
#import "ANOTOrderRate.h"

@interface ANSaleTracking : ANACTOrderTracking

@property (nonatomic, strong) ANRTOrder *order;

@end
