//
//  ANWSFacet.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSFacetValue.h"

@interface ANWSFacet : NSObject

@property (nonatomic, strong) NSString *field;
@property (nonatomic, strong) NSArray *values;

@end
