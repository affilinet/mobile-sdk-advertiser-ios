//
//  ANRTTravelProduct.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRTProduct.h"

@interface ANRTTravelProduct : ANRTProduct

@property (nonatomic, strong) NSDate *departureDate;
@property (nonatomic, strong) NSDate *endDate;
@property (nonatomic, strong) NSString *productType;
@property (nonatomic, assign) BOOL kids;
@property (nonatomic, assign) BOOL adults;
@property (nonatomic, assign) NSInteger numberOfAdults;
@property (nonatomic, strong) NSString *hotelCategory;
@property (nonatomic, strong) NSString *pointOfDeparture;
@property (nonatomic, strong) NSString *pointOfDestination;

@end
