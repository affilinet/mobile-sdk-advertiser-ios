//
//  ANScriptOperation.h
//  AffilinetSDK
//
//  Created by Joao Santos on 23/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANOperation.h"

@interface ANScriptOperation : ANOperation

@property (nonatomic, strong, readonly) NSArray <ANRequest*> *requests;
@property (copy) void(^onFinishOperation)(void);
@property (copy) void(^onFailOperation)(NSError *);
@property (copy) void(^onRequestCompletion)(ANRequest *request, ANRequestResponse *response);

-(id) initWithSession:(ANSession *)session andRequests:(NSArray *) requests;

@end
