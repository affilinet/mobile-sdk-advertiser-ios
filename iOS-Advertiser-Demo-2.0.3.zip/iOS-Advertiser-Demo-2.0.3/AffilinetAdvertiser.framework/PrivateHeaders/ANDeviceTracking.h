//
//  ANDeviceTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 16/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"

@interface ANDeviceTracking : ANHTMLRequest <ANHTMLRequestDelegate>

@end
