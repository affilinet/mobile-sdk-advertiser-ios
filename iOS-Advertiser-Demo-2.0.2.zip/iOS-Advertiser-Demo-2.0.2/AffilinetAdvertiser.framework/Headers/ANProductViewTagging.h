//
//  ANProductViewTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTProduct.h"

@interface ANProductViewTagging : ANAmountTagging

@property (nonatomic, strong) ANRTProduct *product;
@property(nonatomic, strong) NSString *refererURL;

@end
