//
//  ANRequestVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANRequestVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANRequestVC ()

@property (nonatomic, strong) UIBarButtonItem *requestBT;
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicator;
@property (nonatomic, strong) UIBarButtonItem *activityButton;
@end

@implementation ANRequestVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.requestBT = [[UIBarButtonItem alloc]
                                      initWithTitle:@"Request"
                                      style:UIBarButtonItemStylePlain
                                      target:self
                                      action:@selector(doRequest:)];
        
        self.activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        self.activityButton = [[UIBarButtonItem alloc] initWithCustomView:self.activityIndicator];
        [self.activityIndicator startAnimating];
        
        self.navigationItem.rightBarButtonItem = self.requestBT;
    }
    return self;
}

-(void) doRequest:(id) sender {
    self.navigationItem.rightBarButtonItem = self.activityButton;
    
    ANSession *session = [ANSession sharedInstance];
    session.onRequestResponse = ^(ANRequest *request, ANRequestResponse *response) {
        self.navigationItem.rightBarButtonItem = self.requestBT;
        if(response.error != nil) {
            NSLog(@"Request Finished with Error: %@", response.error.localizedDescription);
        }
        else {
            NSLog(@"Request Finished");
        }
    };

    session.onRequestsError = ^(NSError *error) {
        self.navigationItem.rightBarButtonItem = self.requestBT;
        NSLog(@"Requests error: %@", [error domain]);
    };

    session.onRequestsFinished = ^{
        self.navigationItem.rightBarButtonItem = self.requestBT;
        NSLog(@"Requests finished");
    };
    
    [session executeRequests:self.requests];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}

@end
