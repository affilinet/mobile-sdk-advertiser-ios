//
//  ANAppDownloadTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANHTMLRequest.h"

@interface ANAppDownloadTracking : ANHTMLRequest <ANHTMLRequestDelegate>

@property (nonatomic, assign) NSInteger rateNumber;

@end
