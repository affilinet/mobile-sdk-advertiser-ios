//
//  ANRTDatingProduct.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRTProduct.h"
#import "ANRTDatingCustomer.h"

@interface ANRTDatingProduct : ANRTProduct

@property (nonatomic, strong) ANRTDatingCustomer *customer;

@end
