//
//  ANSearchProductsRequest.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import "ANProductsRequest.h"
#import "ANWSShopIdMode.h"
#import "ANWSProductSortBy.h"
#import "ANWSSortOrder.h"
#import "ANWSFilterQuery.h"

@interface ANSearchProductsRequest : ANProductsRequest

@property (nonatomic, strong) NSString *query;
@property (nonatomic, strong) NSArray *shopIds;
@property (nonatomic, strong) NSArray *categoryIds;
@property (nonatomic, assign) BOOL useAffilinetCategories;
@property (nonatomic, assign) BOOL excludeSubCategories;
@property (nonatomic, assign) BOOL withImageOnly;
@property (nonatomic, assign) double minimumPrice;
@property (nonatomic, assign) double maximumPrice;
@property (nonatomic, strong) NSArray *facetFields;
@property (nonatomic, assign) NSInteger facetValueLimit;
@property (nonatomic, assign) ANWSShopIdMode shopIdMode;
@property (nonatomic, assign) ANWSProductSortBy sortBy;
@property (nonatomic, assign) ANWSSortOrder sortOrder;
@property (nonatomic, strong) NSArray *filterQueries;


@end
