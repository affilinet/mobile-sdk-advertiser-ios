//
//  ANCartViewTagging.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrderItem.h"

@interface ANCartViewTagging : ANAmountTagging

@property (nonatomic, strong) NSArray <ANRTOrderItem *> *items;

@property (nonatomic, assign) double total;
@property (nonatomic, assign) double tax;
@property(nonatomic, strong) NSString *refererURL;
@property(nonatomic, strong) NSString *voucherCode;
@property(nonatomic, strong) NSString *voucherDiscount;

@end
