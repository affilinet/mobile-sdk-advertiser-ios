//
//  ANWSCategory.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSItem.h"

@interface ANWSCategory : NSObject <ANWSItem>

@property (nonatomic, assign) NSInteger categoryId;
@property (nonatomic, strong) NSArray *idPathItems;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSArray *titlePathItems;
@property (nonatomic, assign) NSInteger productCount;

@end
