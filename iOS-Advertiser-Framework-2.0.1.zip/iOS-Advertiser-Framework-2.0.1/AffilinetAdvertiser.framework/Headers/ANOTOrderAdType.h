//
//  OTOrderMediaType.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Foundation/Foundation.h>

typedef NSString ANAdType;
extern ANAdType *const kANAdTypeGraphicBanner;
extern ANAdType *const kANAdTypeTextLink;
extern ANAdType *const kANAdTypeHTMLCreative;

@interface ANOTOrderAdType : NSObject

@property (nonatomic, assign) NSInteger adNumber;
@property (nonatomic, assign) ANAdType *adType;

-(id) initWithAdNumber:(NSInteger) adNumber andAdType:(ANAdType *) adType;
-(NSString *) stringValue;

@end
