//
//  ANCheckoutTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrder.h"

#define kAN_PARAM_ORDER_ID @"order_id"

@interface ANCheckoutTagging : ANAmountTagging

@property (nonatomic, strong) ANRTOrder *order;
@property (nonatomic, assign) NSInteger publisherID;
@property (nonatomic, strong) NSString *customerGender;
@property (nonatomic, assign) NSInteger customerAge;
@property (nonatomic, strong) NSString *customerAgeRange;
@property (nonatomic, strong) NSString *customerCountry;
@property (nonatomic, strong) NSString *customerZip;
@property (nonatomic, strong) NSString *customerStatus;
@property (nonatomic, strong) NSString *paymentType;
@property (nonatomic, assign) double shippingGrossPrice;
@property (nonatomic, assign) NSInteger shippingTax;
@property (nonatomic, strong) NSString *shippingType;
@property (nonatomic, strong) NSString *voucherCode;
@property (nonatomic, assign) NSInteger voucherCodeDiscount;
@property (nonatomic, assign) NSInteger tax;
@property (nonatomic, strong) NSString *refererURL;

@end
