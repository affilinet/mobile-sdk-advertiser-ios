//
//  ANCategoryViewTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANRetargetingTagging.h"
#import "ANRTProductCategory.h"

#define kAN_PARAM_PRODUCT_CATEGORY @"product_category"
#define kAN_PARAM_PRODUCT_CLICK_URL @"product_clickUrl"
#define kAN_PARAM_PRODUCT_IMG_URL @"product_imgUrl"

@interface ANCategoryViewTagging : ANRetargetingTagging <ANHTMLRequestDelegate, ANRetargetingTaggingDelegate>

@property (nonatomic, strong) ANRTProductCategory *category;

@end
