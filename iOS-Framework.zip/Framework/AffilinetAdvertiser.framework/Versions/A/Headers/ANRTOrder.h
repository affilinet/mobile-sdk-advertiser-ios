//
//  ANRTOrder.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANRTOrder : NSObject

@property (nonatomic, strong) NSArray *items;
@property (nonatomic, strong) NSString *orderId;
@property (nonatomic, assign) double total;

@end
