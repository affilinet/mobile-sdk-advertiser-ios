//
//  ANBasketTracking.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 28/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANACTOrderTracking.h"
#import "ANOTBasketItem.h"

@interface ANBasketTracking : ANACTOrderTracking

@property (nonatomic, strong) NSDate *orderDate;
@property (nonatomic, strong) NSString *orderDescription;
@property (nonatomic, strong) NSString *orderId;
@property NSArray <ANOTBasketItem *>* basketItems;

@end
