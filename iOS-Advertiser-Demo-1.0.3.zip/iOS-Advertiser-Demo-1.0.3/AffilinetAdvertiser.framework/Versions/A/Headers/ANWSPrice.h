//
//  ANWSPrice.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANWSPrice : NSObject

@property (nonatomic, assign) double oldPrice;
@property (nonatomic, strong) NSString *prefix;
@property (nonatomic, assign) double price;
@property (nonatomic, strong) NSString *suffix;
@property (nonatomic, strong) NSString *displayPrice;

@end
