//
//  ANLeadTrackingVC.m
//  AffilinetSDKDemo
//
//  Created by Patrick Rocliffe on 01/11/2016.
//  Copyright © 2016 affilinet. All rights reserved.
//

#import "ANLeadTrackingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANLeadTrackingVC ()

@property (nonatomic, strong) ANLeadTracking *leadTracking;

@end

@implementation ANLeadTrackingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        self.leadTracking = [[ANLeadTracking alloc] initWithSession:[ANSession sharedInstance]];
        self.leadTracking.rateNumber = 1;
        
        self.leadTracking.order = [[ANRTOrder alloc] init];
        self.leadTracking.order.orderId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        self.leadTracking.order.total = 400;
        
#warning TODO: program_subid
        //self.basketTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2", @"example3"]];
        
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        item1.quantity = 2;
        item1.product = [[ANRTProduct alloc] init];
        item1.product.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item1.product.name = @"Amazing Product 1";
        item1.product.price = 40.45;
        item1.product.oldPrice = 40.45;
        
        ANRTOrderItem *item2 = [[ANRTOrderItem alloc] init];
        item2.quantity = 1;
        item2.product = [[ANRTTravelProduct alloc] init];
        item2.product.productId = (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
        item2.product.name = @"Amazing Product 2";
        item2.product.price = 13.45;
        item2.product.oldPrice = 14.98;
        ((ANRTTravelProduct *)item2.product).departureDate = [NSDate dateWithTimeIntervalSinceNow:0];
        ((ANRTTravelProduct *)item2.product).endDate = [NSDate dateWithTimeIntervalSinceNow:0];
        ((ANRTTravelProduct *)item2.product).productType = @"flight-only";
        ((ANRTTravelProduct *)item2.product).kids = NO;
        ((ANRTTravelProduct *)item2.product).numberOfAdults = 2;
        ((ANRTTravelProduct *)item2.product).hotelCategory = @"NA";
        ((ANRTTravelProduct *)item2.product).pointOfDeparture = @"Lisbon";
        ((ANRTTravelProduct *)item2.product).pointOfDestination = @"Frankfurt";
        
        self.leadTracking.order.items = @[item1, item2];
        
        self.requests = @[self.leadTracking];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}

@end
