//
//  ANAppDelegate.m
//  AffilinetSDKDemo
//
//  Created by Joao Santos on 28/10/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANAppDelegate.h"

#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

#import "ANStartViewController.h"

@interface ANAppDelegate()

@property (nonatomic, strong) ANSession *session;
#warning TODO: investigate
/*
@property (nonatomic, strong) ANBasketOrderTracking *basketTracking;
@property (nonatomic, strong) ANStandardOrderTracking *orderTracking;
@property (nonatomic, strong) ANAppDownloadTracking *appTracking;
*/
@end


@implementation ANAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    
    ANStartViewController *startVC = [[ANStartViewController alloc] init];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:startVC];
    
    [self.window setRootViewController:navController];
    
    
//    ANAdvertiserAccount *account = [[ANAdvertiserAccount alloc] init];
//    account.accountID = @[@12452];
//    account.webServiceUsername = @"webservice";
//    
//    self.session = [ANSession sharedInstance];
//    [self.session openWithAccount:account andCountryCode:CountryCodeGermany];
//    
//    
//    self.basketTracking = [[ANBasketOrderTracking alloc] initWithSession:self.session];
//    self.basketTracking.orderID =  (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
//    self.basketTracking.mediaType = [[ANOTOrderMediaType alloc] init];
//    self.basketTracking.mediaType.mediaType = OTMediaTypeGraphicBanner;
//    self.basketTracking.mediaType.mediaNumber = 1;
//    self.basketTracking.vCode = @"TEST";
//    self.basketTracking.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
//    self.basketTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
//    
//    ANOTBasketItem *basketItem = [[ANOTBasketItem alloc] init];
//    basketItem.articleNumber = @"ArticleNb1";
//    basketItem.productName = @"Amazing Product";
//    basketItem.category = @"jeans";
//    basketItem.brand = @"Versace";
//    basketItem.quantity = 1;
//    basketItem.singlePrice = 200.45;
//    basketItem.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
//    
//    ANOTBasketItem *basketItem2 = [[ANOTBasketItem alloc] init];
//    basketItem2.articleNumber = @"ArticleNb2";
//    basketItem2.productName = @"Amazing Product 2";
//    basketItem2.category = @"jeans 2";
//    basketItem2.brand = @"Versace 2";
//    basketItem2.quantity = 3;
//    basketItem2.singlePrice = 600.45;
//    basketItem2.properties = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
//    
//    self.basketTracking.items = [NSMutableArray arrayWithArray:@[basketItem, basketItem2]];
//
//    self.orderTracking = [[ANStandardOrderTracking alloc] initWithSession:self.session];
//    self.orderTracking.orderID =  (NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)));
//    self.orderTracking.mediaType = [[ANOTOrderMediaType alloc] init];
//    self.orderTracking.mediaType.mediaType = OTMediaTypeGraphicBanner;
//    self.orderTracking.mediaType.mediaNumber = 1;
//    self.orderTracking.vCode = @"TEST";
//    self.orderTracking.currency = [[ANCurrency alloc] initWithCurrencyCode:CurrencyCodeEuro];
//    self.orderTracking.orderValue = 200.45;
//    self.orderTracking.orderRate = [[ANOTOrderRate alloc] init];
//    self.orderTracking.orderRate.rateNumber = 1;
//    self.orderTracking.orderRate.rateMode = OTOrderRateModeSale;
//    self.orderTracking.pSub = [[NSMutableArray alloc] initWithArray:@[@"example1", @"example2"]];
//    
//    self.appTracking = [[ANAppDownloadTracking alloc] initWithSession:self.session];
//    self.appTracking.rateNumber = 1;
//
//    self.session.onRequestResponse = ^(ANRequest *request, ANRequestResponse *response) {
//        if(response.error != nil) {
//            NSLog(@"Request Finished with Error: %@", response.error.localizedDescription);
//        }
//        else {
//            NSLog(@"Request Finished");
//        }
//    };
//    
//    self.session.onRequestsError = ^(NSError *error) {
//        NSLog(@"Requests error: %@", [error domain]);
//    };
//    
//    self.session.onRequestsFinished = ^{
//        NSLog(@"Requests finished");
//    };
//    
//    [self.session executeRequests:@[self.basketTracking, self.orderTracking, self.appTracking]];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
