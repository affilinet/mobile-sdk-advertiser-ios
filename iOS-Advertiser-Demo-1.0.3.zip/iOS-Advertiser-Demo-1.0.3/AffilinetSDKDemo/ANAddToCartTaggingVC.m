//
//  ANAddToCartTaggingVC.m
//  AffilinetSDKDemo
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet. All rights reserved.
//

#import "ANAddToCartTaggingVC.h"
#import <AffilinetAdvertiser/AffilinetAdvertiser.h>

@interface ANAddToCartTaggingVC ()

@property (nonatomic, strong) ANAddToCartTagging *addToCart;

@end

@implementation ANAddToCartTaggingVC

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
        self.addToCart = [[ANAddToCartTagging alloc] initWithSession:[ANSession sharedInstance]];
        self.addToCart.currency = [[ANCurrency alloc] initWithCurrencyCode:ANCurrencyCodeEUR];
        
        // standard product item
        ANRTProduct *product = [[ANRTProduct alloc] init];
        product.category = [[ANRTProductCategory alloc] init];
        product.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        product.productId = [NSString stringWithFormat:@"product-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        product.name = @"Amazing Product";
        product.price = 5.43;
        product.oldPrice = 5.99;
        product.brand = @"Amazing Brand";
        product.rating = 3;
        product.inStock = YES;
        product.onSale = YES;
        product.accessory = NO;
        product.clickURL = @"http://something-product.com";
        product.imageURL = @"http://something-product.com/image.png";
        
        ANRTOrderItem *item1 = [[ANRTOrderItem alloc] init];
        item1.quantity = 2;
        item1.product = product;
        
        // dating item
        ANRTDatingProduct *datingProduct = [[ANRTDatingProduct alloc] init];
        datingProduct.category = [[ANRTProductCategory alloc] init];
        datingProduct.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        datingProduct.productId = [NSString stringWithFormat:@"dating-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        datingProduct.name = @"Amazing Dating Product";
        datingProduct.price = 22.43;
        datingProduct.oldPrice = 19.99;
        datingProduct.brand = @"Amazing Dating Brand";
        datingProduct.rating = 3;
        datingProduct.inStock = YES;
        datingProduct.onSale = YES;
        datingProduct.accessory = NO;
        datingProduct.clickURL = @"http://something-dating.com";
        datingProduct.imageURL = @"http://something-dating.com/image.png";
        
        ANRTDatingCustomer *customer = [[ANRTDatingCustomer alloc] init];
        customer.gender = @"male";
        customer.ageRange = @"18-25";
        customer.zipCode = @"60329";
        customer.wasLoggedIn = NO;
        datingProduct.customer = customer;
        
        ANRTOrderItem *item2 = [[ANRTOrderItem alloc] init];
        item2.quantity = 1;
        item2.product = datingProduct;
        
        // travel item
        ANRTTravelProduct *travelProduct = [[ANRTTravelProduct alloc] init];
        travelProduct.category = [[ANRTProductCategory alloc] init];
        travelProduct.category.pathItems = @[@"Main Category", @"Subcategory", @"Productgroup"];
        travelProduct.productId = [NSString stringWithFormat:@"travel-%@",(NSString *) CFBridgingRelease(CFUUIDCreateString(NULL, CFUUIDCreate(NULL)))];
        travelProduct.name = @"Amazing Travel Product";
        travelProduct.price = 199.95;
        travelProduct.oldPrice = 189.60;
        travelProduct.brand = @"Amazing Travel Brand";
        travelProduct.rating = 7;
        travelProduct.inStock = YES;
        travelProduct.onSale = NO;
        travelProduct.accessory = YES;
        travelProduct.clickURL = @"http://something-travel.com";
        travelProduct.imageURL = @"http://something-travel.com/image.png";
        travelProduct.departureDate = [NSDate dateWithTimeIntervalSince1970:1385025186];
        travelProduct.endDate = [NSDate dateWithTimeIntervalSince1970:1390294999];
        travelProduct.productType = @"Hotel";
        travelProduct.kids = YES;
        travelProduct.numberOfAdults = 2;
        travelProduct.hotelCategory = @"Deluxe";
        travelProduct.pointOfDeparture = @"Frankfurt am Main";
        travelProduct.pointOfDestination = @"Dubai";
        
        ANRTOrderItem *item3 = [[ANRTOrderItem alloc] init];
        item3.quantity = 1;
        item3.product = travelProduct;
        
        //self.addToCart.items = @[item1, item2, item3]; //deprecated
        self.addToCart.item = item1;
        
        self.requests = @[self.addToCart];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
    
    
    return cell;
}


@end
