//
//  ANAddToCartTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrderItem.h"

@interface ANAddToCartTagging : ANAmountTagging

@property (nonatomic, strong) NSArray *items DEPRECATED_MSG_ATTRIBUTE("items is deprecated, addToCart should be used to track a quantity of a single product type being added to cart. To track the contents of the cart, please use ANCartViewTagging.");

@property (nonatomic, strong) ANRTOrderItem *item;
@property(nonatomic, strong) NSString *refererURL;

@end
