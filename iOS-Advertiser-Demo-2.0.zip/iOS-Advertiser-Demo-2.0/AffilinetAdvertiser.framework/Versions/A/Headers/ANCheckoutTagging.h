//
//  ANCheckoutTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANAmountTagging.h"
#import "ANRTOrder.h"

#define kAN_PARAM_ORDER_ID @"order_id"

@interface ANCheckoutTagging : ANAmountTagging

@property (nonatomic, strong) ANRTOrder *order;

@end
