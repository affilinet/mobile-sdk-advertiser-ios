//
//  ANWebserviceResponse.h
//  AffilinetSDK
//
//  Created by João Santos on 15/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ANWSFacet.h"
#import "ANRequestResponse.h"
#import "ANWSShop.h"

@interface ANWebserviceResponse : ANRequestResponse

@property (nonatomic, assign) NSInteger currentPage;
@property (nonatomic, assign) NSInteger totalPages;
@property (nonatomic, assign) NSInteger records;
@property (nonatomic, assign) NSInteger totalRecords;
@property (nonatomic, strong) NSArray *facets;
@property (nonatomic, strong) NSArray *items;
@property (nonatomic, strong) ANWSShop *shop;

@end
