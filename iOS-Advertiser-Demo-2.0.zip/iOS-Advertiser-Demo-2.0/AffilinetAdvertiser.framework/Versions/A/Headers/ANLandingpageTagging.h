//
//  ANLandingpageTagging.h
//  AffilinetSDK
//
//  Created by João Santos on 08/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANProfilingTagging.h"

__deprecated_msg("ANLandingpageTagging is deprecated please use ANPageViewTagging instead.")
@interface ANLandingpageTagging : ANProfilingTagging <ANHTMLRequestDelegate, ANProfilingTaggingDelegate>

@end
