//
//  ANBasketOrderTracking.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import "ANOrderTracking.h"

#define kAN_BASKET_FORM_ID @"affilinetTrackingForm"
#define kAN_PARAM_BASKET @"basket"

@interface ANBasketOrderTracking : ANOrderTracking <ANHTMLRequestDelegate>

@property(nonatomic, strong) NSMutableArray *items;

@end
