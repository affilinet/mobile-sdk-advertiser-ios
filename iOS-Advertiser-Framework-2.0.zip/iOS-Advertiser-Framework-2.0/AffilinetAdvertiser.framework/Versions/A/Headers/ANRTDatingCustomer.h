//
//  ANRTDatingCustomer.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANRTDatingCustomer : NSObject

@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *ageRange;
@property (nonatomic, strong) NSString *zipCode;
@property (nonatomic, assign) BOOL wasLoggedIn;

@end
