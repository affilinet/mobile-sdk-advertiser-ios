//
//  ANACTOrderTracking.h
//  AffilinetSDK
//
//  Created by Patrick Rocliffe on 27/10/2016.
//  Copyright © 2016 affilinet GmbH. All rights reserved.
//

#import "ANACTTagging.h"
#import "ANCurrency.h"
#import "ANRTOrder.h"
#import "ANOTOrderMediaType.h"

#define kAN_PARAM_ORDER_ID @"order_id"
#define kAN_PARAM_NET_PRICE @"net_price"
#define kAN_PARAM_RATE_NUMBER @"rate_number"
#define kAN_PARAM_PUBLISHER_ID @"publisher_id"
#define kAN_PARAM_ORDER_DESCRIPTION @"order_description"
#define kAN_PARAM_CURRENCY @"currency"

#define kAN_PARAM_ORDER_DATE @"order_date"
#define kAN_PARAM_DATE_FORMAT @"date_format"
#define kAN_PARAM_TIME_ZONE @"time_zone"

#define kAN_PARAM_AD_TYPE @"ad_type"
#define kAN_PARAM_AD_NUMBER @"ad_number"

#define kAN_PARAM_PUBLISHER_SUBID @"publisher_subid"
#define kAN_PARAM_PROGRAM_SUBID @"program_subid" 

#define kAN_PARAM_VOUCHER_CODE @"voucher_code"

#define kAN_PARAM_PRODUCT_IDS @"product_ids"

#define kAN_PARAM_CLICK_TIME @"click_time"

#define kAN_PARAM_UID @"uid"

#define kAN_PARAM_BASKET_ITEMS @"basket_items"

#define kAN_PARAM_PRODUCT_ID @"product_id"
#define kAN_PARAM_PRODUCT_NAME @"product_name"
#define kAN_PARAM_PRODUCT_PRICE @"product_price"
#define kAN_PARAM_PRODUCT_CATEGORY @"product_category"
#define kAN_PARAM_PRODUCT_BRAND @"product_brand"
#define kAN_PARAM_PRODUCT_ON_SALE @"product_on_sale"
#define kAN_PARAM_PRODUCT_QUANTITY @"product_quantity"
#define kAN_PARAM_PRODUCT_PROPERTY @"product_property"
#define kAN_PARAM_PRODUCT_RATE_NUMBER @"product_rate_number"
#define kAN_PARAM_PRODUCT_RATE_TYPE @"product_rate_type"
#define kAN_PARAM_PRODUCT_PROPERTY @"product_property"

#define kAN_DATE_FORMAT @"yyyy-MM-ddTHH:mm:ss"

typedef NSString ANAdType;
extern ANAdType *const kANAdTypeGraphicBanner;
extern ANAdType *const kANAdTypeTextLink;
extern ANAdType *const kANAdTypeHTMLCreative;
extern ANAdType *const kANAdTypeBannerRotation;

@interface ANACTOrderTracking : ANACTTagging

@property (nonatomic, strong) ANCurrency *currency;
@property (nonatomic, strong) ANOTOrderMediaType *mediaType;
@property (nonatomic, strong) NSString *publisherID;
@property (nonatomic, strong) NSString *publisherSubID;
@property (nonatomic, strong) NSArray <NSString *>* programSubID;
@property (nonatomic, strong) ANAdType *adType;
@property (nonatomic, assign) NSInteger adNumber;
@property (nonatomic, assign) NSInteger rateNumber;


@property (nonatomic, strong) NSString *voucherCode;

@property (nonatomic, strong) NSDate *clickDate;

@end
