//
//  ANRTProductCategory.h
//  AffilinetSDK
//
//  Created by João Santos on 07/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANRTProductCategory : NSObject

@property (nonatomic, strong, readonly) NSString *name;
@property (nonatomic, strong) NSString *categoryId;
@property (nonatomic, strong) NSArray *pathItems;
@property (nonatomic, strong) NSString *clickURL;
@property (nonatomic, strong) NSString *imageURL;

@end
