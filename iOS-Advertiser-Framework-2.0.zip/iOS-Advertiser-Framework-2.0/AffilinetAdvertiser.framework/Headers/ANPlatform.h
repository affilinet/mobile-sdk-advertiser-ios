//
//  ANPlatform.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    ANCountryCodeDE,
    ANCountryCodeAT,
    ANCountryCodeCH,
    ANCountryCodeGB,
    ANCountryCodeFR,
    ANCountryCodeES,
    ANCountryCodeNL,
    ANCountryCodeBE,
    ANCountryCodeLU
} ANCountryCode;

@interface ANPlatform : NSObject

-(id) initWithCountryCode:(ANCountryCode) countryCode;
-(NSString *) stringValue;
-(NSString *) domain;
-(NSString *) ACTdomain;
-(NSString *) programID;
-(NSString *) containerTrackingDomain;
-(NSString *) trackingDomain;

@end
