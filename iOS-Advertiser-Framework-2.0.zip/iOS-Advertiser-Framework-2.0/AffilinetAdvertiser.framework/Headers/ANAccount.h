//
//  ANAccount.h
//  AffilinetSDK
//
//  Created by Joao Santos on 14/10/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ANAccount : NSObject

@property (nonatomic, strong) NSArray <NSNumber*>* accountID;
@property (nonatomic, strong) NSString *webServicePassword;


@end
