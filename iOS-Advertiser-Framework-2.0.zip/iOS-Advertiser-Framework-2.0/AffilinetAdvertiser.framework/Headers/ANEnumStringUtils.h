//
//  LogoEnumStringUtils.h
//  AffilinetSDK
//
//  Created by João Santos on 17/01/14.
//  Copyright (c) 2014 affilinet GmbH. All rights reserved.
//
#import "ANWSShopLogoScale.h"
#import "ANWSProductImageScale.h"
#import "ANWSShopIdMode.h"
#import "ANWSSortOrder.h"
#import "ANWSProductSortBy.h"

@interface ANEnumStringUtils : NSObject

+(NSString *) stringFromShopLogoScale: (ANWSShopLogoScale) scale;
+(ANWSShopLogoScale) shopLogoScaleFromNSString:(NSString *)scale;

+(NSString *) stringFromProductImageScale:(ANWSProductImageScale) scale;
+(ANWSProductImageScale) productImageScaleFromNSString:(NSString *) scale;

+(NSString *) stringFromShopIdMode:(ANWSShopIdMode) shopIdMode;
+(NSString *) stringFromSortOrder:(ANWSSortOrder) sortOrder;
+(NSString *) stringFromSortBy:(ANWSProductSortBy) sortBy;

@end
