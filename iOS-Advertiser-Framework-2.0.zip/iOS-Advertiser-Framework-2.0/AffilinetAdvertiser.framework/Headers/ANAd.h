//
//  ANAd.h
//  AffilinetSDK
//
//  Created by João Santos on 25/11/13.
//  Copyright (c) 2013 affilinet GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ANRequest.h"

typedef enum {
    ANFeaturePhoneMediumBanner,
    ANFeaturePhoneLargeBanner,
    ANSmartphoneBanner,
    ANSmartphoneWideBanner,
    ANLeaderboard,
    ANSquareBanner,
    ANFullSizeBanner,
    ANSkyscraper,
    ANWideSkyscraper,
    ANMediumRectangle,
    ANCustomAdSize
} ANAdSize;

@interface ANAd : ANRequest

@property (nonatomic, assign) ANAdSize size;
@property (nonatomic, assign) CGSize customSize;

-(NSString *) adHtml;
-(CGSize) getCGSize;

@end
